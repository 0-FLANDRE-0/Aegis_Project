# FUZE_ZEM_A

[보고서](docs/missile/fuze-zem/A/REPORT.md) · [모델](docs/missile/fuze-zem/A/MODEL.md) · [재현](docs/missile/fuze-zem/A/REPRODUCE.md) · [검증](docs/missile/fuze-zem/A/evidence/verification.json)

D=deterministic SAM acquisition; Z=ZEM sign; T=observed TRACK termination. Final game=DZT. F is superseded/rejected. No full ENV_D sweep. Legacy 120-row table is historical/recalculation-required. Execution HTML is supplied separately. Previous non-final duplicate raw runs listed in DELIVERY_MANIFEST stay on the branch and are excluded from this ZIP; final revision3 raw records are complete.

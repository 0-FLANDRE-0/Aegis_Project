# KAPPA_PIP_LOS_A

[Report](docs/missile/kappa/A/REPORT.md) | [Reproduction](docs/missile/kappa/A/README.md) | [Evidence](docs/missile/kappa/A/evidence/verification.json)

Limited 14-condition acceptance only; no full envelope sweep or global stability certification. Execution HTML is delivered separately. Raw JSON/CSV retain .gz compression. ENV_C and RECOVERY_A reports are historical pre-patch records. See DELIVERY_MANIFEST.json for every member hash.

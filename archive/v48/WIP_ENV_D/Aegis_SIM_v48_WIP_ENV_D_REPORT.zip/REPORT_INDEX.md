# REG_K + ENV_D

[Report](docs/envelope/D/REPORT.md) | [Reproduction](docs/envelope/D/README.md) | [Verification](docs/envelope/D/evidence/verification.json)

Execution HTML is delivered separately. Raw gzip JSON/CSV retain their .gz suffix. The invalidated incomplete-hooks pilot/partial sweep is explicitly segregated and is not ENV_D data. Existing ENV_C is historical AIR-point-target, pre-Kappa guidance.

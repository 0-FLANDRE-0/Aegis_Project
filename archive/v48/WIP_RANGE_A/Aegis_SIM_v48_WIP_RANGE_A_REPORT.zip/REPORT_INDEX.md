# RANGE_A + ENV_C

- [범위·0단계·변경8값·목표 도달·R1–R5](docs/missile/range/A/REPORT.md)
- [ENV_C 전체96조합·발사거리/요격거리·ENV_B 비교·120궤적](docs/envelope/C/REPORT.md)
- [저고도 이탈/횡단21건 조사 — 수정 없음](docs/envelope/C/results/LOW_ALT_INVESTIGATION.md)
- [재현](docs/envelope/C/README.md) · [검증 환경](docs/missile/range/A/TEST_ENVIRONMENT.md)
- [전체 수록 파일·체크섬](DELIVERY_MANIFEST.json)

이 ZIP에는 실행 HTML이 없다. 별도의 HTML ZIP을 받는다. 큰 원시JSON/CSV는 읽을 수 있게 풀어서 수록한다. 전체 원격 readback 영수증은 발행 후 GitHub range-a-env-c 브랜치 docs/missile/range/A/remote-publication.json에 기록한다.

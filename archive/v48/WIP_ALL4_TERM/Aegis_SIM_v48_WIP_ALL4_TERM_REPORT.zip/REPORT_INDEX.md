# ALL4_TERM + ENV_B 리포트

- [누적 ALL4 종료·배터리·브라우저 검수](docs/missile/termination/A/REPORT.md)
- [미사일 그래프/96조합 사거리 표/로프트 관찰/E1–E4](docs/envelope/B/REPORT.md)
- [재현 순서](docs/missile/termination/A/README.md)
- [검증 환경과 후보/재시도 구분](docs/missile/termination/A/TEST_ENVIRONMENT.md)
- [파일 목록과 SHA-256](DELIVERY_MANIFEST.json)

실행 HTML은 별도의 HTML ZIP에 있다. 이 ZIP의 원시JSON/CSV는 압축을 풀어 읽을 수 있게 수록했다. 전체 원격 readback 영수증은 발행 후 GitHub의 missile-b4-termination 브랜치 docs/missile/termination/A/remote-publication.json에 기록한다.

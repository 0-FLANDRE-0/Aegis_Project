# RANGE_RECOVERY_A

[Report](docs/missile/range/RECOVERY_A/REPORT.md) | [Reproduction](docs/missile/range/RECOVERY_A/README.md) | [Evidence](docs/missile/range/RECOVERY_A/evidence/verification.json)

Partial recovery; one moving-target baseline success is still lost. No full envelope sweep. Execution HTML is delivered separately. Raw JSON/CSV retain .gz compression. See DELIVERY_MANIFEST.json for every member hash.

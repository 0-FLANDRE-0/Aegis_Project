# LAUNCH_HANDOFF_A WIP

[Report](docs/missile/launch-handoff/A/REPORT.md), [contract](docs/missile/launch-handoff/A/MODEL.md), [reproduce](docs/missile/launch-handoff/A/REPRODUCE.md), [verification](docs/missile/launch-handoff/A/final-evidence/verification.json).

Launch mechanism verified for the specified cases; full regression approval WITHHELD. Three new failure shots / two conditions and six original exact-state assertion failures are disclosed. No gain/physics/fuze retuning. No main merge or release/tag. Full final raw JSON.gz included. Two redundant CSV expansions remain on the branch; compact current-tick and 10Hz CSV included. Product HTML is delivered separately. Old ENV_D table remains HISTORICAL/recalculation-required.

# FUZE_ZEM_A — 결정론적 SAM 탐지 + 독립 ZEM/종료기 검증

기준 `reg-k-env-d@058273c1f4b91c0d0c595e5399aaa967aa443f1c`, 별도 `fuze-zem-a`. 최종 실행 파일은 **DZT**. 기존 브랜치/main 병합·PR·Actions 실행 없음. 전체 ENV_D 175,955발/최대사거리 스윕은 **실행하지 않았다**.

## 판정과 변경

재추첨안 F는 기존 성공 16건을 실패로 바꿔 **승인하지 않았다**. 사용자 추가 지시에 따라 SAM 표적 acquisition의 난수를 제거한 D를 새로 설계했다. 최종 D/Z/T는 각각 독립 검증했고 결합 DZT도 기존 성공의 신규 실패가 없었다. 이는 아래 제한 조건의 결과이며 모든 교전에서 명중한다는 뜻은 아니다.

- D: 기존 반경·TDD 빔·방위별 RCS·상대속도·해면 배경잡음에 따른 정규화 SNR와 실제 시간 적분. Pd 임계값 변환/강제 detected 사용 없음.
- Z: ZEM 정의 target−missile과 autopilot 소비 경로를 확인한 뒤 보정 가속 부호만 +로 수정.
- T: 유효 TRACK의 무조건 종료 우회를 제거. 관측 CPA 통과·지속 opening·오차보다 큰 거리 증가·복귀 기동 가능성을 함께 검사. 숨겨진 표적 좌표 사용 없음.
- 유지: Dynamic B4·Kappa/TGO90·PN/APN 이득·사거리·추진/항력/질량/기동 한계·배터리·시커·기존 CPA/신관 처리 지연·파편/Pk·작전 저장/UI.

정적 복원 비교: 기존 선언 3,766개 byte 동일, 기존 함수 변경은 5개뿐. 추가 helper/정규화 상수는 [DZT diff](changes/DZT.diff), 분리 diff는 [D](changes/D.diff) / [Z](changes/Z.diff) / [T](changes/T.diff). 모델·재질 등 assets 0–12 byte 동일.

## 1. 모델과 재현

계산식·단위·SIM_TUNED 상수·감쇠/초기화/획득 유지·swept 처리·RNG 경계는 [MODEL.md](MODEL.md), 실행은 [REPRODUCE.md](REPRODUCE.md). 수치는 D 비행 시험 전에 고정했으며 결과를 보고 임계값/Pd/난수 상수로 명중률을 맞추지 않았다.

기존 고정 draw는 ENV_D navigation seed2에서 `0.9190980815328658`. 여러 유효 빔 통과 동안 Pd가 약0.87에 머물면 같은 draw가 매번 거부해 20m 안쪽 CPA도 탐지 실패했다. 재추첨안 F는 매60Hz 독립 추첨이 아닌 encounter별 단일 독립 추첨이었지만, 다른 seed에서 같은 종류의 pass-wide 실패를 새로 만들었다. 최종 D는 draw를 acquisition에서 읽지 않는다.

프레임 사이 접근은 기존 상대 SI 선분을 반경과 교차한 뒤 과거 노출만 적분한다. 탐지 시각은 substep으로 기록하되 기존 burst/damage 엔진은 60Hz 그대로다.

## 2. 공통 180발 A/B

36조건 × 기존 ENV_D 고정5시드. 근/중/장거리, 정지·접근250·이탈250·횡단250m/s, 고도30m–20km, 4종. 아래 성공은 native ASM의 KILL/STRUCT_FAIL/DAMAGED 효과이며 lethal도 따로 표시한다.

| 후보 | 효과 성공/180 | lethal | BASE 성공→실패 | BASE 실패→성공 |
|---|---:|---:|---:|---:|
| BASE | 138 | 137 | 0 | 0 |
| F | 142 | 141 | 16 | 20 |
| D | 159 | 158 | 0 | 21 |
| Z | 138 | 138 | 0 | 0 |
| T | 138 | 137 | 0 | 0 |
| ZT | 138 | 138 | 0 | 0 |
| DZT | 159 | 159 | 0 | 21 |

원시 조건/결과: [AB_RESULTS.csv](AB_RESULTS.csv), [seed2 전부](SEED2.csv), [SUMMARY.json](SUMMARY.json). 최종 T는 revision3만 사용했다. 이전 T 반복 자료를 합산하지 않는다.

### F에서 새로 실패한 16건 — 전수 원인 분류

16건 모두 유효 빔 안의 샘플은 있었으나 encounter draw가 그 pass의 모든 Pd보다 컸다. 탐지 allow 0, 이후 SEA_IMPACT. 물리적 신호 부족/처리 지연/기동 한계로 분류하지 않는다. 확률 표본 변경으로 발생한 불합격이며 자동 상수 보정 없이 F를 폐기했다. D 및 최종 DZT는 16/16 회복했다. 기존 F의 실패→성공20건도 D/DZT가 20/20 유지했다.

| 사례 | F CPA(m) | draw / 최대Pd | D | DZT |
|---|---:|---|---|---|
| SM2_NEAR_STATIC_S4 | 0.003 | 0.93170 / 0.87000 | 회복 | 회복 |
| SM2_LOW_INBOUND_S5 | 0.422 | 0.90078 / 0.87000 | 회복 | 회복 |
| SM2_MID_INBOUND_S1 | 0.708 | 0.93087 / 0.87000 | 회복 | 회복 |
| SM2_MID_INBOUND_S4 | 0.716 | 0.89649 / 0.87000 | 회복 | 회복 |
| SM2_MID_STATIC_S1 | 0.006 | 0.88660 / 0.87000 | 회복 | 회복 |
| SM2_LOW_OUTBOUND_S3 | 1.508 | 0.94196 / 0.87000 | 회복 | 회복 |
| SM2ER_NEAR_STATIC_S4 | 0.003 | 0.97173 / 0.87000 | 회복 | 회복 |
| SM2ER_MID_INBOUND_S5 | 0.483 | 0.93031 / 0.87000 | 회복 | 회복 |
| SM2ER_LOW_OUTBOUND_S3 | 0.522 | 0.99041 / 0.88086 | 회복 | 회복 |
| SM6_MID_INBOUND_S3 | 0.483 | 0.89946 / 0.87000 | 회복 | 회복 |
| SM6_MID_INBOUND_S5 | 0.489 | 0.94482 / 0.87000 | 회복 | 회복 |
| SM6_MID_STATIC_S3 | 0.270 | 0.88757 / 0.87000 | 회복 | 회복 |
| SM6_LONG_STATIC_S1 | 0.243 | 0.88155 / 0.87000 | 회복 | 회복 |
| SM6_LONG_STATIC_S4 | 0.242 | 0.93571 / 0.87000 | 회복 | 회복 |
| SM6_LOW_OUTBOUND_S3 | 0.533 | 0.89364 / 0.88006 | 회복 | 회복 |
| SM6_LOW_OUTBOUND_S5 | 0.518 | 0.94697 / 0.88002 | 회복 | 회복 |

[16건 상세](OLD_REROLL_REGRESSIONS.csv) / [20건 상세](OLD_REROLL_RECOVERIES.csv). D/Z/T/DZT의 신규 실패는 공통 180발에서 각각0건이다. 따라서 새 실패에 대한 신호 부족·짧은 노출·빔 이탈·처리 지연 분류를 임의로 만들어 넣지 않았다. 기존 실패 중 아래 기하 미스·유도/지원 문제는 그대로 남는다.

### 짧은 고속 노출·빔 밖·저고도

| 추가 조건 | BASE | F | D | DZT |
|---|---:|---:|---:|---:|
| 30m/접근680m/s, 4종×5시드 효과 성공 | 17/20 | 16/20 | 20/20 | 20/20 |

추가 F는 신규 실패3건/회복2건, D 및 DZT는 신규 실패0건/회복3건. 빔 밖 통과와 약신호, 0.4ms 신호만 있는 단위 조건은 획득하지 않았다. 8,000m/s로 프레임 사이를 통과하는 충분한 신호는 swept 적분으로 획득했다. 이 단위 속도는 수치 경계 시험이며 게임 표적 제원이 아니다.

실제 로그 [FUZE_SIGNALS.csv.gz](FUZE_SIGNALS.csv.gz): 신호 품질, E, 연속 노출, 탐지 성립 substep, rejection 사유. 원래 Pd/draw도 별도 열에 남겼다.

![신호 누적](plots/signal_accumulation.png)

## 3. 자연 RF/EKF와 실제 월드

자연 RF 시험은 ship cue와 표적의 직선 등속만 fixture가 제어한다. onboard RF 합성/탐지/EKF는 강제로 유효하게 만들지 않는다. 공중 점표적 대신 실제 Kh-35U 구조/피해 경로를 사용했다. 전체 simulateFixedTick 시험과 구분한다.

| 후보 | NORMAL lethal/16 | fault 포함 lethal/28(해당시) | 원래 명중 신규 실패 |
|---|---:|---:|---:|
| BASE | 10/16 | 18/28 | 0 |
| F | 13/16 | 13/28 — 미실행 | 0 |
| D | 13/16 | 13/28 — 미실행 | 0 |
| Z | 10/16 | 10/28 — 미실행 | 0 |
| T | 10/16 | 18/28 | 0 |
| ZT | 10/16 | 18/28 | 0 |
| DZT | 13/16 | 21/28 | 0 |

RF LOSS / REACQUIRE / NO_ACQUISITION은 4종씩 별도 포함했다. DL/SARH 대체 지원이 유효하면 RF 미획득만으로 무조건 종료/실패시키지 않는 원래 규칙을 유지한다. 자연 RF seed2에서 MR/ER/SM-6의 미작동3건은 D가 회복했다. [NATURAL_RF.csv](NATURAL_RF.csv).

**종료기의 자연 RF 한계:** 고고도 근거리 사례 일부는 관측 단절/재획득, 실제 복귀 제어/관측 접근, 또는 ARH 활성화 이전의 대체 지원 때문에 보수적 guard가 유지되어 LOW_SPEED까지 비행한다. 이 상태들을 truth로 덮어쓰거나 단순 시간 초과로 종료하지 않았다. 모든 자연 시커 비명중을 즉시 종료하도록 해결했다고 주장하지 않는다.

전체 fixed tick은 원본 자연 탐지→LOCK→정식 VLS harness를 사용했다. BASE8발 + DZT8발 모두 실제 WebGL 렌더 프레임이 전진했고 29개 assertion씩 통과했다. 기존 MR/ER 명중4건 보존, 기존 SM-6/ESSM 실패는 실패로 남았다. OFF/ON은 종료기 토글이며 신관 D 토글과 다르다.

120초 전체 월드: 무표적 해시와 SM-6 100km/5km/seed12002 전투 해시 모두 BASE=DZT. 전투 사례는 양쪽 모두 TERMINAL_MISS_POST_CROSS로, 과거 다른 빌드의 명중으로 표기하지 않았다.

## 4. 조사만 한 사항

| 미사일, 5km/20km seed1 | BASE 최초CPA m | Z 최초CPA m | BASE 종료 | 최종 DZT 종료 |
|---|---:|---:|---|---|
| SM2ER | 338.299 | 270.976 | LOW_SPEED 418.30s | TERMINAL_MISS_TRACKED_DIVERGENCE 21.72s |
| SM6 | 317.229 | 223.445 | LOW_SPEED 414.48s | TERMINAL_MISS_TRACKED_DIVERGENCE 22.03s |

이 두 최초 미스는 약80m 탐지 반경 바깥이므로 신관 난수 결함과 별개다. ZEM 부호를 바로잡으면 CPA는 개선되지만 여전히 반경 밖이다. 새 종료기는 이 관측 기반 miss를 처리하며 유도 성능을 강화하지 않는다.

- 큰 제어 요구: `computeTruePN3D`의 LOS 곡률/r²와 ZEM의 1/tgo² 항이 작은 교차시간에서 커진다. 일부 raw 요구는 수백–수천 G이나 기존 cap/물리 가용G는 수십 G이고 실제 적용도 제한된다. 로그에 raw/command/achieved/available을 분리했다. PN을 전역3–5배로 높이지 않았다.
- 단계 역전: `computeGuidanceAccelV1`이 현재 거리로 매 tick phase를 다시 선택하고 post-pass latch/hysteresis가 없어, 거리 증가 시 ENDGAME→TERMINAL→TRANSITION→MIDCOURSE로 되돌아간다. 관측 pass state와 phase 재계획의 결합/재획득 hysteresis가 개선 후보지만 이번에는 수정하지 않았다.
- 관측이 유지된 미스: 기존 `gameFlightTerminationEvaluateV48`의 fresh TRACK return null이 원인. 새 T는 관측 pass 이력을 검사한다. 실제 return 제어가 있는 경우와 단순 노이즈 명령을 분리한다. 초기 T1의 끝없이 늘어나는 half-turn grace와 T2의 tiny APN 보호 문제를 시험에서 찾아 T3로 보완했다. 이전 반복은 history에 보존했다.

![고고도 근거리 궤적](plots/high_near_paths.png)

![제어 요구](plots/high_near_control.png)

[원시 10Hz/종말 궤적](HIGH_NEAR_TRAJECTORIES.csv.gz), `SUMMARY.json.research`의 최초CPA/가용G/phase 시각. 정상 MR/ESSM 명중은 보존됐다.

## 5. 검증 수치

| 검사 | 결과 |
|---|---|
| 기존 엔진/전역RNG/ZEM 단위 | PASS · 32 checks |
| 신호·빔·arming·시간 적분 | PASS · 30 checks |
| 관측 종료·복귀·재획득·공분산 guard | PASS · 13 checks |
| 5함수 범위/비변경 함수·asset/문법 | PASS · 17 checks |
| 게임 실제 함수/private 동등성 | PASS · 41 checks |
| clean core/수상 proximity/과거 표 경고 | PASS · 10 checks |
| 30/60/120Hz + 7ms 위상 이동 | 탐지 시점 최대 편차 14.716ns (0.000014716ms); 신호 적분기만 |
| 동일 입력의 nav seed 변경 | 5 seed 모두 acquisition 결과 동일 |
| 결정성 재실행 | 48쌍/96발 전체 반환값 비트 동일 |
| 해면 클러터 난수 보존 | 4종×60,000회, 양 버전 전체 난수열 hash 동일. MR/ER/SM-6 각251회, ESSM8회 trigger |
| 실제 게임 vs private | 8조건, 시간/좌표/고도/속도 최대오차0, 신관 로그·native 피해/RNG 동일 |
| private 월드 격리 | 게임 월드·RNG·tick 변화0 |
| WebGL 실제 발사 | BASE8 + DZT8, 각29/29 assertion. 기존 명중 신규 실패0 |
| 120초 상태 해시 | 무표적·지정 전투 모두 BASE=DZT |
| 기존 도메인 | PASS · 420 |
| 기존 UI | PASS · 88 |
| 기존 정상/대체지원/RF/배터리/정식VLS | PASS · 300발씩 BASE/DZT, 신규 실패0 |

### 기존 release 입력의 변경 전후

| 구분 | BASE 성공 | DZT 성공 | 성공→실패 |
|---|---:|---:|---:|
| normals (240발/버전) | 170 | 170 | 0 |
| dual (36발/버전) | 32 | 32 | 0 |
| faults (12발/버전) | 6 | 6 | 0 |
| battery (8발/버전) | 0 | 0 | 0 |
| request (4발/버전) | 4 | 4 | 0 |

핵심 계산 시간: 공통 BASE/F/Z 포함 초기6variant 1080발 166.15s, 결정론적 D/DZT1 360발45.20s, 최종 T/ ZT/ DZT +추가조건636발59.41s. 자연 RF 초기160발271.97s, 최종84발204.80s. 동시 실행 부하를 포함하므로 단일 사격 성능 벤치마크로 해석하지 않는다. 전체 release/회귀 실행 시간은 `evidence/release-executions.json`과 개별 로그를 따른다.

## 6. 남은 범위

- 전체 ENV_D 재측정 없음. 내장 120칸은 과거 결과이고 후보의 `__ENV_D__.status()`는 match=false / 재계산 필요. 새 지도 링이나 발사 권한에 연결하지 않았다.
- 미스 이후 phase 역전, 초고고도 근거리 에너지/제어 한계, 보수적 복귀 guard로 끝까지 남는 자연 RF 일부 사례는 원인/개선 후보만 보고한다.
- 실제 RF 수신기 교정 자료, 현장 무기 성능, 실제 폰 GPU/실시간 대규모 교전 보증은 이 SIM_TUNED 모델의 검증 범위가 아니다.
- 중간 오류는 모델 보정으로 숨기지 않았다: WeakMap을 diagnostic JSON에 직렬화하려던 첫 실행은 폐기, readout만 필터했다. sparse 체크아웃에서 빠진 옛 테스트 의존 파일은 같은 commit 파일을 복구했다. 초기 clutter unit은 proxArmed 누락으로 전부 비활성인 fixture였고 arming을 명시해 재실행했다. 수치 모델 변경 없음.

이 ZIP의 source와 raw logs는 진단 전용이며 최종 게임 HTML에는 주입한 TEST_ONLY fixture/계측 wrapper가 없다.

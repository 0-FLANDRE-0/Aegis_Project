"""B/C combat comparison and equal fixed ticks at 1/8/16/64x.

The six cold-aircraft cases use the existing full-simulation fixture, comparing
all existing combat/EW/network/team state and RNG. Only aviation's intentionally
new schema and host profiler observations are excluded from the paired state.
"""
import argparse
import hashlib
import json
import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'docs/multiship/G'))
from browser_g import launch, load_fleet


def baseline(a):
    source_path = ROOT / 'docs/multiship/H4/regression_baseline.py'
    source = source_path.read_text()
    source = source.replace("['performance','ew','network','tactical','maneuver','attack','team']", "['performance','aviation']")
    source = source.replace('AEGIS_MULTI_SHIP_H4_BASELINE_COMPARISON', 'AEGIS_HELO_C_BASELINE_COMPARISON').replace('H3/H4', 'HELI_B/HELI_C')
    source = source.replace("abs(count_vls(pair['baseline'])-count_vls(pair['candidate']))<=1", "count_vls(pair['baseline'])==count_vls(pair['candidate'])")
    source = source.replace('exclude existing EW/network/tactical metadata, new attack settings and profiler', 'exclude only profiler and the changed aviation schema; include EW/network/tactical/maneuver/attack/team')
    source = source.replace('Ownship defense/maneuver utility is OFF by default. No allied peers or Harpoon launch in this paired regression; H3-on maneuver and native defense are verified separately.', 'Cold helicopters, defense/maneuver utility OFF. No allied peers or Harpoon launch in these six paired cases. Active aircraft are tested by the separate fixed-clock, altitude and native suites.')
    scope = {'__file__': str(source_path), '__name__': '_helo_c_baseline'}
    exec(compile(source, str(source_path), 'exec'), scope)
    previous_argv = sys.argv
    sys.argv = [str(source_path), str(a.baseline), str(a.html), str(a.out)]
    try:
        scope['main']()
    except SystemExit:
        pass  # Collect its report alongside the independent clock fixture.
    finally:
        sys.argv = previous_argv
    report = json.loads((a.out / 'baseline-comparison.json').read_text())
    # Progress is useful while running, but duplicates the complete final case
    # report and is not part of the published evidence set.
    (a.out / 'baseline-comparison-progress.json').unlink(missing_ok=True)
    return report


def clock(a):
    errors, rows = [], []
    with sync_playwright() as pw:
        browser = launch(pw)

        # Only prevent background RAF before boot. The served production HTML
        # is unmodified; runFramesToTicks uses the actual frame accumulator and
        # complete fixed-step simulation at each selected time multiplier.
        class ControlledBrowser:
            def new_page(self, **options):
                page = browser.new_page(**options)
                page.add_init_script('window.requestAnimationFrame=()=>0;')
                return page

        controlled = ControlledBrowser()
        for scale in [1, 8, 16, 64]:
            page = load_fleet(controlled, a.html.read_bytes(), own='DDG_119_LATE_FLIGHT_IIA', ally=None, enemy=None, errors=errors)
            row = page.evaluate('''scale=>{
                const d=__NAVAL_SIM_DIAG__,api=__HELO__;
                __WIP125_DIAG__.forcePreSail();document.getElementById('wip125DepartBtn').click();d.setTerrainDiagBypass(true);
                const before=api.snapshot(),commands=[];
                for(const h of before.aircraft){
                    commands.push(api.command(h.id,'SET_ALTITUDE',{altitudeM:h.slot===0?1200:200}));
                    commands.push(api.command(h.id,'LAUNCH'));
                    commands.push(api.command(h.id,'WAYPOINT',{x:2000+h.slot*1000,y:1500}));
                    commands.push(api.command(h.id,'ROUTE_APPEND',{x:1000,y:2200}));
                }
                commands.push(api.command(before.aircraft[0].id,'FOLLOW_SHIP'));
                d.setShipRudderTest(6);
                const run=d.runFramesToTicks(60,scale,16000),after=api.snapshot();
                return {scale,commands,run,after,rng:__HARPOON_DIAG_A__.snapshot().rng,
                    contract:d.simulationUpdateContractV48Wip11A(),core:__CORE_SELFTEST_FAILURES__};
            }''', scale)
            rows.append(row)
            page.close()
        browser.close()
    signature = lambda r: json.dumps({'after': r['after'], 'rng': r['rng']}, sort_keys=True)
    checks = {str(r['scale']) + '.exact': signature(r) == signature(rows[0]) for r in rows}
    checks['allCommandsAccepted'] = all(c['ok'] for r in rows for c in r['commands'])
    checks['differentAltitudesPreserved'] = all([h['targetAltitudeM'] for h in r['after']['aircraft']] == [1200, 200] for r in rows)
    checks['fixed60Hz'] = all(r['contract']['fixedTickHz'] == 60 for r in rows)
    checks['corePass'] = all(not r['core'] for r in rows)
    report = {'pass': all(checks.values()) and not errors, 'checks': checks, 'rows': rows, 'errors': errors,
              'htmlSha256': hashlib.sha256(a.html.read_bytes()).hexdigest()}
    (a.out / 'clock.json').write_text(json.dumps(report, indent=2) + '\n')
    return report


def main():
    p = argparse.ArgumentParser()
    p.add_argument('baseline', type=Path)
    p.add_argument('html', type=Path)
    p.add_argument('out', type=Path)
    a = p.parse_args()
    a.out.mkdir(parents=True, exist_ok=True)
    paired, fixed = baseline(a), clock(a)
    checks = {r['ship'] + ':' + r['scenario'] + ':' + k: v for r in paired['cases'] for k,v in r['checks'].items()}
    checks.update({'clock:' + k: v for k,v in fixed['checks'].items()})
    report = {'pass': paired['pass'] and fixed['pass'], 'checks': checks,
              'baselineSha256': hashlib.sha256(a.baseline.read_bytes()).hexdigest(),
              'htmlSha256': hashlib.sha256(a.html.read_bytes()).hexdigest(),
              'errors': paired['errors'] + fixed['errors'],
              'reports': ['baseline-comparison.json', 'clock.json']}
    (a.out / 'regression.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'pass': report['pass'], 'checks': len(checks), 'failed': [k for k,v in checks.items() if not v], 'errors': report['errors']}))
    raise SystemExit(0 if report['pass'] else 1)


if __name__ == '__main__':
    main()

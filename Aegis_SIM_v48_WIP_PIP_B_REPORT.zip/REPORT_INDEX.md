# PIP_B + ENV_A 리포트

- [PiP/락온 창 변경과 P1–P5 검수](docs/pip/B/REPORT.md)
- [미사일 그래프/96조합 사거리 표/로프트 관찰/E1–E4](docs/envelope/A/REPORT.md)
- [재현 순서](docs/pip/B/REPRODUCE.md)
- [검증 환경과 후보/재시도 구분](docs/pip/B/TEST_ENVIRONMENT.md)
- [파일 목록과 SHA-256](DELIVERY_MANIFEST.json)

실행 HTML은 별도의 HTML ZIP에 있다. 이 ZIP의 원시JSON/CSV는 압축을 풀어 읽을 수 있게 수록했다. 전체 원격 readback 영수증은 발행 후 GitHub의 pip-b-env-a 브랜치 docs/pip/B/remote-publication.json에 기록한다.

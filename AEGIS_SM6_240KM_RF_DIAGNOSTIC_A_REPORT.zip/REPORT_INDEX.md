# SM-6 240km RF 진단

[결과 보고서](docs/missile/sm6-rf/A/REPORT.md) · [검수](docs/missile/sm6-rf/A/verification.json) · [재현](docs/missile/sm6-rf/A/REPRODUCE.md)

NATIVE 전체 반환값 동등성 선행 통과. ARH 추정 오차 → 권한 채택/값 소비 → Kappa 명령 → 기동/항력 증가 → 뒤의 COAST 순서를 확인했다. 반사실 둘 다 HANDOFF 명중을 회복한다. 제품 코드/계수 변경0. 측정 생성/연관/EKF 내부의 단일 세부 원인은 아직 미확정이다. 입력 kit, 선행 NATIVE2발 + 이후6발 raw, CSV, 그림과 재현 도구를 포함한다. 실행 HTML은 포함하지 않으며 제품 기준은 launch-handoff-a@99c2ef33이다.

# 현재 SM-6 ARH 측정 계약 확인

[결과](docs/missile/arh-measurement/A/REPORT.md) · [검수](docs/missile/arh-measurement/A/verification.json) · [재현](docs/missile/arh-measurement/A/REPRODUCE.md)

실제 활성 SM6 프로파일에서도 각도/시커 중심 의존과 생성 잡음/R 불일치가 모두 재현됐다. actual native22점과VM오차0. 계약 검사의FAIL과 재현 절차의PASS를 구분한다. 제품 코드/계수 수정0, 새 비행 적분0.240km 수정후 회복은 아직 시험하지 않았다. 실행 HTML은 포함하지 않는다.

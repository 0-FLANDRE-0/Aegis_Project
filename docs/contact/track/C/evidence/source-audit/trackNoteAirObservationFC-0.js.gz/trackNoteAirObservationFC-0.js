function trackNoteAirObservationFC(tr){
 tr._radar3dAirStepFC=simStepCounter;tr._surface2DOnlyFC=false;
 // A subsequently accepted 3-D observation supersedes a 2-D height prior.
 tr._surfaceMotionPriorWip13B13=false;
}

  // ===== WIP13B14 CROSS-DOMAIN ASSOCIATION CONTINUITY =====
  // Domain classification is an output of measured RF evidence, not a pre-association partition.
  // Low, slow, extended echoes may therefore be compared with an established surface file even
  // when one noisy dwell labels the plot AIR. Conversely, a surface-routed plot may recover an
  // early low/slow UNKNOWN/AIR file. Tight kinematic/evidence gates keep fast sea-skimmers separate.
  const WIP13B14_CROSS_DOMAIN_ASSOCIATION_CONTRACT=Object.freeze({
    schema:'AEGIS_CROSS_DOMAIN_RADAR_ASSOCIATION_V48_WIP13B14',schemaVersion:1,
    inputs:Object.freeze(['ANONYMOUS_MEASUREMENT','EKF_COVARIANCE','DOMAIN_EVIDENCE','TRACK_KINEMATICS']),
    prohibitedInputs:Object.freeze(['truthRef','objectId','entityId','rfId','_truthObject','_physicsKind']),
    surfaceLikeMaxHeightM:140,surfaceLikeMaxSignificantDopplerMps:45,
    crossDomainSurfaceTrackMaxAltitudeM:120,crossDomainSurfaceTrackMaxSpeedMps:90,
    airToSurfaceNisGate:25,surfaceToAirNisGate:25,domainSwitchConfirmations:3,truthUsedForAssociation:false,
    surfaceAssociationOrder:Object.freeze(['ESTABLISHED_SURFACE','UNASSIGNED_EARLY_AIR_OR_UNKNOWN']),
    policy:'ASSOCIATE_BEFORE_HARD_DOMAIN_PARTITION__PRESERVE_FAST_LOW_ALTITUDE_ASM_SEPARATION'
  });
  const WIP13B14_CROSS_DOMAIN_ASSOC_STATS={airPlotToSurfaceTrack:0,surfacePlotToAirTrack:0,rejectedFastOrAloft:0,lastTrackId:null,lastRoute:null,lastNis:null};
  function resetWip13b14CrossDomainAssociationStats(){Object.assign(WIP13B14_CROSS_DOMAIN_ASSOC_STATS,{airPlotToSurfaceTrack:0,surfacePlotToAirTrack:0,rejectedFastOrAloft:0,lastTrackId:null,lastRoute:null,lastNis:null});}
  function trackSurfaceBackedWip13B14(tr){return !trackHasAirObservationFC(tr)&&!!tr&&(tr.domain==='SURFACE'||tr.classification==='SURFACE'||tr._surfaceMotionPriorWip13B13||tr._surfaceSensorContributorsWip13B9||(tr.sensorSource??'').startsWith('BRIDGEMASTER_E'));}
  function shipboardRadarLowSlowSurfaceEchoWip13B14(plot={}){
    const evidence=plot.domainEvidence??plot,features=evidence?.features??{},height=Math.abs(Number(features.heightM??plot.estimatedSurfaceHeightM??plot.z??999)),significantDoppler=Math.abs(Number(features.significantDopplerMps??plot.surfaceRelativeDopplerMps??plot.radialMps??999)),along=Math.max(0,Number(features.alongM??plot.observedRangeHalfExtentM??0)),cross=Math.max(0,Number(features.crossM??plot.observedProjectedHalfWidthM??0)),verticalStructure=Math.max(0,Number(features.verticalStructure)||0),surfaceScore=clamp(Number(evidence?.surface)||0,0,1),missileScore=clamp(Number(evidence?.missile)||0,0,1),backgroundScore=clamp(Number(evidence?.background)||0,0,1),extended=Math.max(along,cross)>=10&&verticalStructure>.04;
    return height<=WIP13B14_CROSS_DOMAIN_ASSOCIATION_CONTRACT.surfaceLikeMaxHeightM&&significantDoppler<=WIP13B14_CROSS_DOMAIN_ASSOCIATION_CONTRACT.surfaceLikeMaxSignificantDopplerMps&&backgroundScore<.68&&(surfaceScore>=.24||extended)&&!(missileScore>.78&&missileScore>surfaceScore+.24);
  }
  function trackMayAcceptSurfacePlotCrossDomainWip13B14(tr,plot={}){
    if(!tr||tr.sensorDetected===false||tr.truthEnded)return false;
    if(trackHasAirObservationFC(tr))return true; // 2-D contribution; same native NIS gate, no height/domain overwrite.
    if(trackSurfaceBackedWip13B14(tr))return true;
    const speedMps=Math.hypot(worldSpeedToMps(tr.vx??0),worldSpeedToMps(tr.vy??0),Number(tr.vz)||0),altM=Math.abs(Number(tr.z)||0),confidence=clamp(Number(tr.classificationConfidence)||0,0,1);
    if((tr.classification==='ASM'&&confidence>.68)||speedMps>WIP13B14_CROSS_DOMAIN_ASSOCIATION_CONTRACT.crossDomainSurfaceTrackMaxSpeedMps||altM>WIP13B14_CROSS_DOMAIN_ASSOCIATION_CONTRACT.crossDomainSurfaceTrackMaxAltitudeM){WIP13B14_CROSS_DOMAIN_ASSOC_STATS.rejectedFastOrAloft++;return false;}
    const e=plot.domainEvidence??{},surface=Number(e.surface)||0,background=Number(e.background)||0;
    return surface>.48&&background<surface;
  }
  function trackMayAcceptAirPlotCrossDomainWip13B14(tr,plot={}){
    if(!tr||tr.sensorDetected===false||tr.truthEnded)return false;
    if(tr._surface2DOnlyFC&&Number.isFinite(plot.elRad))return true; // An assumed surface height is not a measured domain partition; native 4-D NIS still decides.
    if(!trackSurfaceBackedWip13B14(tr))return true;
    const ok=shipboardRadarLowSlowSurfaceEchoWip13B14(plot);if(!ok)WIP13B14_CROSS_DOMAIN_ASSOC_STATS.rejectedFastOrAloft++;return ok;
  }
  function noteCrossDomainAssociationWip13B14(tr,plot,route,nis){
    if(!tr)return;
    const cross=route==='AIR'&&trackSurfaceBackedWip13B14(tr)?'airPlotToSurfaceTrack':(route==='SURFACE'&&!trackSurfaceBackedWip13B14(tr)?'surfacePlotToAirTrack':null);if(!cross)return;
    WIP13B14_CROSS_DOMAIN_ASSOC_STATS[cross]++;WIP13B14_CROSS_DOMAIN_ASSOC_STATS.lastTrackId=tr.trackId;WIP13B14_CROSS_DOMAIN_ASSOC_STATS.lastRoute=route;WIP13B14_CROSS_DOMAIN_ASSOC_STATS.lastNis=Number.isFinite(nis)?nis:null;
  }
  function surfaceAssociationTrackEntriesWip13B14(plots=[]){
    const list=Array.isArray(plots)?plots:[plots];return [...tracks].filter(([,tr])=>tr&&tr.sensorDetected!==false&&(trackSurfaceBackedWip13B14(tr)||list.some(plot=>trackMayAcceptSurfacePlotCrossDomainWip13B14(tr,plot))));
  }
  function surfaceAssignmentsPreferEstablishedWip13B14(plots,nisFn,gate,excludedTrackIds=new Set(),eligiblePlotIndices=null){
    const plotIndices=eligiblePlotIndices??plots.map((_,i)=>i),assigned=new Map(),usedTracks=new Set(excludedTrackIds),blockedCost=1e6;
    // Transient assignment metadata only; never stored on a canonical track.
    assigned.trackBHeldPlots=new Set();
    const assignStage=(indices,trackEntries,cross)=>{
      if(!indices.length||!trackEntries.length)return;
      const stageGate=cross?Math.min(gate,WIP13B14_CROSS_DOMAIN_ASSOCIATION_CONTRACT.surfaceToAirNisGate):gate,dummyCost=stageGate+.5;
      const costs=indices.map(i=>[...trackEntries.map(([,tr])=>{if(cross&&!trackMayAcceptSurfacePlotCrossDomainWip13B14(tr,plots[i])){if(TRACK_A_DIAG.enabled)trackATraceEventA('CANDIDATE',plots[i],{...trackATraceContextA('SURFACE_RADAR',plots[i].source,ACTIVE_SHIP_RUNTIME.entityId),route:'SURFACE_BATCH',appliedModel:'SURFACE_ASSOCIATION',appliedDimension:nisFn===trackSurfacePositionAssociationNisWip13B9?2:(Number.isFinite(plots[i].radialMps)?3:2),appliedFields:nisFn===trackSurfacePositionAssociationNisWip13B9||!Number.isFinite(plots[i].radialMps)?['rangeM','azRad']:['rangeM','azRad','radialMps'],gateUnits:'NIS',trackId:tr.trackId,decision:'REJECT',reason:'NATIVE_CROSS_DOMAIN_PARTITION',gate:stageGate});return blockedCost;}const nis=nisFn(tr,plots[i]);if(TRACK_A_DIAG.enabled)trackATraceEventA('CANDIDATE',plots[i],{...trackATraceContextA('SURFACE_RADAR',plots[i].source,ACTIVE_SHIP_RUNTIME.entityId),route:'SURFACE_BATCH',appliedModel:'SURFACE_ASSOCIATION',appliedDimension:nisFn===trackSurfacePositionAssociationNisWip13B9?2:(Number.isFinite(plots[i].radialMps)?3:2),appliedFields:nisFn===trackSurfacePositionAssociationNisWip13B9||!Number.isFinite(plots[i].radialMps)?['rangeM','azRad']:['rangeM','azRad','radialMps'],gateUnits:'NIS',trackId:tr.trackId,nis,gate:stageGate,decision:nis<=stageGate?'ELIGIBLE':'REJECT',reason:'NATIVE_NIS'});return nis<=stageGate?nis:blockedCost;}),...new Array(indices.length).fill(dummyCost)]),cols=(TRACK_B_IMPLEMENTATION_MODE!=='ACTIVE'||TRACK_B_DIAG.enabled)?bridgeMasterEMinCostAssignmentV35(costs):[];
      // Keep the existing stage-specific Hungarian solution for SHADOW. The
      // graph reuses the native position/Doppler NIS values in costs verbatim.
      const legacyPairs=[],trackBPairs=[];
      for(let row=0;row<cols.length;row++){
        const col=cols[row];if(col<0||col>=trackEntries.length||costs[row][col]>stageGate)continue;
        legacyPairs.push({i:indices[row],id:trackEntries[col][0],nis:costs[row][col]});
      }
      for(let row=0;row<indices.length;row++)for(let col=0;col<trackEntries.length;col++){
        const nis=costs[row][col];if(!(nis<=stageGate))continue;
        const [id,tr]=trackEntries[col],i=indices[row];trackBPairs.push({i,id,nis,sanity:trackBGeometryB(tr,plots[i],'SURFACE'),evidence:trackBEvidenceStableB(tr,plots[i],nisFn===trackSurfacePositionAssociationNisWip13B9||(nisFn===trackSurfaceRadarAssociationNisV35&&!Number.isFinite(plots[i].radialMps))?'SURFACE_POSITION':'UNSUPPORTED_SURFACE_ASSOCIATION',simStepCounter*SIM_FIXED_DT)});
      }
      const trackBSelection=trackBSelectB({plotCount:plots.length,pairs:trackBPairs,legacyPairs,gate:stageGate,route:cross?'OWN_SURFACE_CROSS':'OWN_SURFACE_ESTABLISHED',observerShip:ACTIVE_SHIP_RUNTIME.entityId,timeS:simStepCounter*SIM_FIXED_DT,tick:simStepCounter});
      for(const i of trackBSelection.heldPlots)assigned.trackBHeldPlots.add(i);
      // These are stage-local reservations, not caller usedTracks or accepted hits.
      for(const id of trackBSelection.heldTracks)usedTracks.add(id);
      for(const q of trackBSelection.pairs){assigned.set(q.i,{trackId:q.id,nis:q.nis,cross});usedTracks.add(q.id);}
    };
    const live=[...tracks].filter(([id,tr])=>!usedTracks.has(id)&&tr&&tr.sensorDetected!==false).sort((a,b)=>a[0]-b[0]);
    assignStage(plotIndices,live.filter(([,tr])=>trackSurfaceBackedWip13B14(tr)),false);
    const leftovers=plotIndices.filter(i=>!assigned.has(i)&&!assigned.trackBHeldPlots.has(i)),crossTracks=live.filter(([id,tr])=>!usedTracks.has(id)&&!trackSurfaceBackedWip13B14(tr)&&leftovers.some(i=>trackMayAcceptSurfacePlotCrossDomainWip13B14(tr,plots[i])));
    assignStage(leftovers,crossTracks,true);return assigned;
  }
  function wip13b14CrossDomainAliasAudit(){
    const rows=[...tracks].filter(([,tr])=>trackIsDisplayable(tr)).map(([trackId,tr])=>({trackId,classification:tr.classification??'UNKNOWN',domain:tr.domain??'UNKNOWN',surfaceBacked:trackSurfaceBackedWip13B14(tr),xM:worldToMeters(tr.x),yM:worldToMeters(tr.y),zM:Number(tr.z)||0,vxMps:worldSpeedToMps(tr.vx??0),vyMps:worldSpeedToMps(tr.vy??0),sensorAgeS:tr.sensorAge??null,lifecycle:trackLifecycleState(tr),confidence:tr.classificationConfidence??null}));
    const suspectPairs=[];for(let i=0;i<rows.length;i++)for(let j=i+1;j<rows.length;j++){const a=rows[i],b=rows[j],separationM=Math.hypot(a.xM-b.xM,a.yM-b.yM),relativeSpeedMps=Math.hypot(a.vxMps-b.vxMps,a.vyMps-b.vyMps);if((a.surfaceBacked||b.surfaceBacked)&&separationM<=80&&relativeSpeedMps<=30)suspectPairs.push({a:a.trackId,b:b.trackId,separationM,relativeSpeedMps,classifications:[a.classification,b.classification],domains:[a.domain,b.domain],lifecycles:[a.lifecycle,b.lifecycle]});}
    return {schema:'AEGIS_CROSS_DOMAIN_TRACK_ALIAS_AUDIT_V48_WIP13B14',rows,suspectPairs,pass:suspectPairs.length===0};
  }
  function surfaceTrackExpectedRevisitSWip13B9(tr){
    if(Number.isFinite(tr?._spySurfaceFreshS)&&tr._spySurfaceFreshS<=1.2)return SENSOR_MODEL.spy1dv.surfaceTrackRevisitS;
    if(Number.isFinite(tr?._spq9bSurfaceFreshS)&&tr._spq9bSurfaceFreshS<=2.5)return SPQ9B_NOMINAL_REVISIT_S;
    return BRIDGEMASTER_E_NOMINAL_REVISIT_S;
  }

  function updateSensorTrackMeasurement(id, meas, meta={}){
    const source=meta.source??meas.source??'SENSOR';
    const trackABefore=TRACK_A_DIAG.enabled?trackAStateA(id==null?null:tracks.get(id)):null;
    if(TRACK_A_DIAG.enabled)trackATraceEventA('RECEIVED',meas,{...trackATraceContextA(trackAKindA(meas,source),source,ACTIVE_SHIP_RUNTIME.entityId,meas),route:'PLAYER_MEASUREMENT',trackId:id,decision:'PENDING'});
    const truthRef=normalizeTrackTruthRefV27(meta.truthRef);
    if(id==null&&truthRef)id=trackIdForTruthV27(truthRef.domain,truthRef.objectId,true);
    // Anonymous sensor plots receive a combat-system ID only after association has failed.
    // This allocation carries no reverse truth index and is therefore safe for false plots too.
    if(id==null)id=allocateTrackIdV31();
    let tr=tracks.get(id),created=false;
    if(!tr){
      const ownVxW=mpsToWorldSpeed(Number.isFinite(meas.sensorVxMps)?meas.sensorVxMps:worldSpeedToMps(aircraft._vx??0)),ownVyW=mpsToWorldSpeed(Number.isFinite(meas.sensorVyMps)?meas.sensorVyMps:worldSpeedToMps(aircraft._vy??0));
      const relVxMps=(meas.radialMps??0)*(meas.losUx??0),relVyMps=(meas.radialMps??0)*(meas.losUy??0),relVzMps=(meas.radialMps??0)*(meas.losUz??0);
      tr=getOrMakeTrack(id,meas.x,meas.y,ownVxW+mpsToWorldSpeed(relVxMps),ownVyW+mpsToWorldSpeed(relVyMps),meas.z,relVzMps,truthRef);
      created=true;
      tr.sensorHits=0;tr.confirmed=false;
      // First plot initializes a physically meaningful anisotropic covariance: range/Doppler
      // are relatively well observed, while transverse velocity starts intentionally uncertain.
      tr._kfX=null;tr._kfP=null;
      if(surfaceSensorFamilyWip13B9(source)){
        const surrogate={...meas,elRad:0,radialMps:0,radialVelSigmaMps:180,elSigmaDeg:20,losUz:0};
        trackEkfInit(tr,surrogate);
        tr._kfP[_mIdx(3,3,6)]=SENSOR_MODEL.bridgeMasterE.surfaceVelSigmaInitMps**2;
        tr._kfP[_mIdx(4,4,6)]=SENSOR_MODEL.bridgeMasterE.surfaceVelSigmaInitMps**2;
        tr._kfP[_mIdx(2,2,6)]=SENSOR_MODEL.bridgeMasterE.surfaceZSigmaM**2;
        tr._kfP[_mIdx(5,5,6)]=SENSOR_MODEL.bridgeMasterE.surfaceVzSigmaMps**2;
        trackApplySurfaceDomainConstraint(tr,meas.surfaceReferenceZM??8);
      }else trackEkfInit(tr,meas);
    }

    let trackAAppliedGate=null;
    const isVisual=source==='VISUAL';
    const isBridgeMasterE=source.startsWith('BRIDGEMASTER_E');
    const isSpq9bSurface=source.startsWith('SPQ9B_SURFACE');
    const isSpySurface=source.startsWith('SPY1DV_SURFACE');
    const isSurfaceRadar=isBridgeMasterE||isSpq9bSurface||isSpySurface;
    const isRadar=source.startsWith('SPY1DV') || source.startsWith('SPQ9B');
    if(isSurfaceRadar){
      const gate=isSpySurface?SENSOR_MODEL.spy1dv.surfaceNisGate:(isSpq9bSurface?64:SENSOR_MODEL.bridgeMasterE.nisGate);
      if(TRACK_A_DIAG.enabled)trackAAppliedGate=gate;
      if(!trackEkfUpdateSurfaceRadar2D(tr,meas,{nisGate:gate})){if(TRACK_A_DIAG.enabled)trackATraceEventA('UPDATE',meas,{...trackATraceContextA('SURFACE_RADAR',source,ACTIVE_SHIP_RUNTIME.entityId),route:'PLAYER_MEASUREMENT',trackId:id,decision:'REJECT',reason:'NATIVE_FILTER_REJECT',nis:tr._kfNis,gate,before:trackABefore,after:trackAStateA(tr)});if(created)tracks.delete(id);return null;}
    }else if(isRadar){
      const taskType=meta.taskType??'';
      const nisGate=taskType==='PRECISION_REACQUIRE'?TRACK_FILTER_MODEL.nisGatePrecisionReacquire:(taskType==='TRACK_REACQUIRE'?TRACK_FILTER_MODEL.nisGateReacquire:(taskType.startsWith('SEARCH_')||taskType==='TRACK_CONFIRM'?TRACK_FILTER_MODEL.nisGateSearch:TRACK_FILTER_MODEL.nisGateNormal));
      if(TRACK_A_DIAG.enabled)trackAAppliedGate=nisGate;
      if(!trackEkfUpdateRadar(tr,meas,{nisGate})){if(TRACK_A_DIAG.enabled)trackATraceEventA('UPDATE',meas,{...trackATraceContextA('AIR_RADAR',source,ACTIVE_SHIP_RUNTIME.entityId),route:'PLAYER_MEASUREMENT',trackId:id,decision:'REJECT',reason:'NATIVE_FILTER_REJECT',nis:tr._kfNis,gate:nisGate,before:trackABefore,after:trackAStateA(tr)});if(created)tracks.delete(id);return null;}
    }else if(isVisual){
      meas.altitudeSigmaM=Math.max(30,(meas.rangeSigmaM??100)*0.7);
      trackEkfUpdateCartesianPosition(tr,meas);
    }else{
      // Non-SPY sensor adapters enter the canonical covariance track.
      // A first external plot already initialized P from its covariance: do not count it twice.
      if(!created||source!=='OFFBOARD_C')trackEkfUpdateCartesianPosition(tr,meas);
    }

    if(isRadar&&!isSurfaceRadar)trackNoteAirObservationFC(tr);
    else if(created&&isSurfaceRadar)tr._surface2DOnlyFC=true;
    if(truthRef)bindTrackTruthV27(tr,truthRef);
    tr.truthEnded=false;tr.truthEndReason=null;tr.sensorHits=(tr.sensorHits??0)+1;
    const needHits=isVisual?1:(isSpySurface?SENSOR_MODEL.spy1dv.surfaceConfirmHits:(isSpq9bSurface?2:(isSurfaceRadar?SENSOR_MODEL.bridgeMasterE.confirmHits:SENSOR_MODEL.spy1dv.confirmHits)));
    tr.confirmed=tr.confirmed||tr.sensorHits>=needHits;
    tr.sensorDetected=true;tr.sensorSource=source;tr.sensorAge=0;networkNoteLocalG(ACTIVE_SHIP_RUNTIME,tr,source);
    if(source!=='OFFBOARD_C')tr.identificationEvidence??='LOCAL_SENSOR';
    if(tr.observationReportsC&&source!=='OFFBOARD_C')tr.observationReportsC.localAtS=simStepCounter*SIM_FIXED_DT;
    tr.bearingSigmaDeg=meas.azSigmaDeg??null;tr.elevationSigmaDeg=meas.elSigmaDeg??null;
    tr._lastDetQuality=meas.quality??0.5;tr.ttl=TRACK_HARD_TTL;tr.lastUpdateSeen=true;tr._lastMeasurementStep=simStepCounter;tr.memActive=false;tr._belowHorizon=false;
    if(meta.isASM)tr.isASM=true; // internal association only; classification remains measurement-derived
    if(!(isSurfaceRadar&&trackHasAirObservationFC(tr)))updateTrackClassification(tr,{...meta,domainEvidence:meta.domainEvidence??meas.domainEvidence});
    if(isSurfaceRadar){recordSurfaceSensorContributorWip13B9(tr,source,meas);tr._spyExpectedRevisitS=surfaceTrackExpectedRevisitSWip13B9(tr);}
    trackRefreshDerivedQuality(tr);
    // A3 consumes only the completed observation/classification state. It never reads truth metadata.
    updateTrackOperationalStateA3(tr,{mode:typeof engagementControlMode==='string'?engagementControlMode:'MANUAL',assessment:typeof wip118ControlState==='object'?wip118ControlState?.assessments?.get(id):null});
    if(TRACK_A_DIAG.enabled)trackATraceEventA('UPDATE',meas,{...trackATraceContextA(trackAKindA(meas,source),source,ACTIVE_SHIP_RUNTIME.entityId,meas),route:'PLAYER_MEASUREMENT',trackId:tr.trackId,decision:created?'CREATE':'ACCEPT',nis:isRadar||isSurfaceRadar?tr._kfNis:null,gate:trackAAppliedGate,nativeHitIncrement:1,finalSource:tr.sensorSource,before:trackABefore,after:trackAStateA(tr)});
    return tr;
  }

  function getOrMakeTrack(id, x, y, vx, vy, z_m=OWN_ALT_M, vz_mps=0, truthRef=null){
    if(!tracks.has(id)){
      tracks.set(id, {
        ...createTrackMetadataV26(trackFileSerial++,id,truthRef),
        x, y, vx, vy,
        z: z_m, vz: vz_mps,   // ✅ 고도/상승률

        age: 0, ttl: TRACK_HARD_TTL,
        lastUpdateSeen: true,
        memActive:false,
        sensorDetected:true,
        sensorSource:'LEGACY',
        sensorAge:0,
        sensorHits:1,
        confirmed:false,
        measurementSigmaM:100,
        classification:'UNKNOWN',

        // MEM(표시용) 불확실성: 진행/측방(속도/방향 기반)
        memAge: 0,
        memSigAlongKm: 0.06,
        memSigCrossKm: 0.04,
        memDir: 0,
        memDispX: 0, memDispY: 0,
        memTargetX: 0,
        memTargetY: 0,

        // ===== INS-style MEM state =====
        memLostOutOfSector: false,
        memTime: 0,

        memSigPosKm: 0.06,
        memSigVelMps: 10.0,
        memSigAccMps2: 2.2,

        memBiasAx: 0,
        memBiasAy: 0,
        memBiasAz: 0,         // ✅ 수직 가속 바이어스(INS 드리프트 느낌)

        // 고도 불확실성 (초기값)
        memSigAltM: 60.0,
        memSigVzMps: 6.0,

        // Track quality system (0-1)
        trackQuality: 1.0,       // 1.0=firm, 0.5=degraded, 0.0=lost
        _missFrames: 0,          // consecutive frames without update
        _lastDetQuality: 1.0,    // last detection quality (LOS × seaskim × notch)
        _memReason: null,        // 'HORIZON','SECTOR','NOTCH','CLUTTER','MISS'
        _recoveryBlend: 0,       // 0=MEM, 1=firm (smooth transition)
      });
    } else {
      const tr = tracks.get(id);
      if(truthRef)bindTrackTruthV27(tr,truthRef);
      // Smooth recovery: if was in MEM, blend toward measurement
      if(tr.memActive && tr._recoveryBlend < 0.5){
        // Recovering from MEM: blend old position with new measurement
        const blend = 0.6; // how fast to snap to new measurement
        tr.x = lerp(tr.x, x, blend);
        tr.y = lerp(tr.y, y, blend);
        tr.vx = lerp(tr.vx, vx, blend);
        tr.vy = lerp(tr.vy, vy, blend);
        tr.z = lerp(tr.z ?? z_m, z_m, blend);
        tr.vz = lerp(tr.vz ?? vz_mps, vz_mps, blend);
        tr._recoveryBlend = clamp((tr._recoveryBlend ?? 0) + 0.3, 0, 1);
      } else {
        tr.x = x; tr.y = y; tr.vx = vx; tr.vy = vy;
        tr.z = z_m; tr.vz = vz_mps;
        tr._recoveryBlend = 1.0;
      }
    }
    return tracks.get(id);
  }


  // ===== Lock cursor =====
  const lockCursor = {
    nx: 0, ny: -0.3,    // start slightly above center
    rx: RADAR_RANGE_WORLD,
    ry: RADAR_RANGE_WORLD,
    x: 0, y: 0
  };

  // ===== Target spawning =====
  const targetPool = [];
  let nextTargetId = 1;

  // ===== V48 WIP13A SURFACE TARGET FOUNDATION =====
  // WIP13A2 closes the target-ship loop: common RF reflectors can draw a hostile ASM onto this
  // physical entity, and an actual swept hull contact feeds material penetration, coarse structural
  // damage, fire and flooding. Sensor plots remain anonymous; entityId never crosses into tracks.
  const EMPTY_CONTAINER_TEST_HULK_V1=deepFreezeShipProfileV48Wip09({
    schema:'AEGIS_SURFACE_TARGET_PROFILE_V48_WIP13A',schemaVersion:2,id:'EMPTY_CONTAINER_TEST_HULK_V1',
    physicsWip13C9:{
      mass:{cgZM:4,basis:'SIM_ESTIMATED_EMPTY_HULK_MASS_DISTRIBUTION_NOT_SHIPYARD_DATA'},
      hydrostatics:{modelId:'SHIP_DYNAMIC_STABILITY_V48_WIP04',initialGMM:2.45,gridXM:2,gridYM:.5,thrustPerKg:.25,powerPerKg:5.5,engineResponseS:5,rollDamping:.22,rudderAreaM2:24,equilibriumDraftMinM:-6.5,equilibriumDraftMaxM:17},
      survival:{criticalWaterM3:7500,disableWaterM3:14000,sinkWaterM3:21000,capMomentM4:85000,capMinWaterM3:7000,capHoldS:12,sinkHoldS:20,capsizedHoldS:10,sinkRateMps:.45,lostDraftM:60,responseS:8,hydroSinkDraftM:12}
    },revision:'V48_WIP13C9',
    identity:{classId:'SIM_GENERIC_210M_CONTAINER_HULK',label:'Empty container test hulk',role:'UNMANNED_INSTRUMENTED_TARGET',crew:0,cargo:'NONE',fuel:'GAS_FREE',propulsion:'SECURED',basis:'PUBLIC_MERCHANT_PROPORTIONS__SIM_TUNED_NOT_A_REAL_SHIP'},
    coordinates:{frame:'TARGET_LOCAL_METRES',longitudinal:'+X_BOW',transverse:'+Y_STARBOARD',vertical:'+Z_UP',headingRadZero:'+X_BOW',referenceWaterlineZM:0},
    visualReference:{basis:'PHOTO_DERIVED_GENERIC_NOT_EXACT_REPLICA',ship:'Kyokuyo JAPANMAX / STRAITS CITY',source:'https://www.kyokuyoshipyard.com/en/products/container-carrier',notes:'Empty hatch deck, side passages, tower accommodation, bridge wings and forecastle; retain authored 210m target dimensions, not the reference vessel dimensions.'},
    geometry:{
      lengthM:210,beamM:32.2,mouldedDepthM:17.6,baselineDraftM:6.5,baselineFreeboardM:11.1,airDraftM:43.2,
      // x, deck half-beam, deck z, waterline half-beam, lower-chine half-beam, lower-chine z, keel z.
      // The same stations drive the collision mesh and Three.js hull; there is no visual-only hitbox.
      stations:[[-105,10.8,10.8,7.8,2.0,-.8,-1.2],[-102,12.5,10.8,9.3,3.4,-1.7,-2.6],[-98,14,10.8,11.6,5.4,-3.0,-4.2],[-92,15.2,10.8,13.9,9.6,-4.7,-5.8],[-84,15.9,10.9,15.0,11.9,-5.1,-6.3],[-72,16.1,10.9,15.7,13.4,-5.35,-6.5],[-56,16.1,11,15.9,13.8,-5.45,-6.5],[-40,16.1,11,15.9,13.8,-5.45,-6.5],[-24,16.1,11,15.9,13.8,-5.45,-6.5],[-8,16.1,11.1,15.9,13.8,-5.45,-6.5],[8,16.1,11.1,15.9,13.8,-5.45,-6.5],[24,16.1,11.1,15.9,13.8,-5.45,-6.5],[40,16.1,11.2,15.9,13.8,-5.4,-6.5],[54,16.1,11.3,15.8,13.4,-5.3,-6.4],[66,16.0,11.5,15.4,12.5,-5.2,-6.3],[76,15.7,11.8,14.5,10.8,-5.1,-6.2],[84,14.8,12.25,12.6,8.5,-5,-6.1],[90,12.8,12.7,9.8,6.2,-4.9,-6],[95,10.1,13.15,6.9,4.2,-4.6,-5.8],[99,7.3,13.55,4.1,2.9,-4.15,-5.45],[102,4.5,13.85,1.8,2.4,-3.8,-5.1],[104,2.1,14.05,.65,1.85,-3.6,-4.6],[105,.16,14.15,.10,.45,-3.45,-3.7]],
      cargoHatches:[[65,83,21.0],[40,61,24.2],[14,36,24.5],[-12,10,24.5],[-38,-16,24.5],[-65,-42,24.2]],
      lashingBridgeXM:[63,38,12,-14,-40,-67],
      deckhouse:{x0:-94,x1:-70,yHalf:14.9,z0:10.8,z1:34.1,tiers:[{id:'ACCOMMODATION_LOWER',x0:-94,x1:-70,yHalf:11.9,z0:10.8,z1:20.4},{id:'ACCOMMODATION_MIDDLE',x0:-92,x1:-70,yHalf:10.6,z0:20.4,z1:29.8},{id:'ACCOMMODATION_UPPER',x0:-90,x1:-71,yHalf:10.2,z0:29.8,z1:30.4}],bridgeX0:-85,bridgeX1:-69.5,bridgeYHalf:11.2,bridgeZ0:30.4,bridgeZ1:33.6,wingHalf:15.55},
      funnel:{x0:-94,x1:-85,yHalf:3.15,topX0:-92.7,topX1:-86.1,topYHalf:2.7,z0:27.0,z1:38.3},
      hitVolumes:[
        {id:'ACCOMMODATION_LOWER',kind:'SUPERSTRUCTURE',x0:-94,x1:-70,y0:-11.9,y1:11.9,z0:10.8,z1:20.4},
        {id:'ACCOMMODATION_MIDDLE',kind:'SUPERSTRUCTURE',x0:-92,x1:-70,y0:-10.6,y1:10.6,z0:20.4,z1:29.8},
        {id:'ACCOMMODATION_UPPER',kind:'SUPERSTRUCTURE',x0:-90,x1:-71,y0:-10.2,y1:10.2,z0:29.8,z1:30.4},
        {id:'BRIDGE',kind:'SUPERSTRUCTURE',x0:-85,x1:-69.5,y0:-11.2,y1:11.2,z0:30.4,z1:33.6},
        {id:'FUNNEL_LOWER',kind:'FUNNEL',x0:-94,x1:-85,y0:-3.15,y1:3.15,z0:27,z1:34},
        {id:'FUNNEL_UPPER',kind:'FUNNEL',x0:-92.7,x1:-86.1,y0:-2.7,y1:2.7,z0:34,z1:38.3}
      ]
    },
    signature:{
      basis:'SIM_TUNED_ASPECT_ENVELOPES__NOT_MEASURED_CLASS_DATA',referenceHeightM:36,seekerCentroidHeightM:11.5,
      // Aspect knots are bow, forward-quarter, beam, aft-quarter, stern.
      rcsM2:{S:[140,430,1900,510,230],X:[105,350,1540,410,185],IJ:[78,270,1180,325,145]},minimumM2:12
    },
    protection:{basis:'SIM_TUNED_COMMERCIAL_SCANTLINGS',shellMaterial:'GRADE_A_SHIP_STEEL',yieldStrengthMPa:235,sideThicknessMm:18,bottomThicknessMm:22,weatherDeckThicknessMm:16,superstructureThicknessMm:8,watertightBulkheadThicknessMm:10,innerDeckThicknessMm:9},
    damageModel:{
      basis:'COARSE_EMPTY_MERCHANT_STRUCTURE__SIM_TUNED',zoneCount:9,initialLongitudinalStrength01:1,initialKeelIntegrity01:1,initialSideIntegrity01:1,initialDeckIntegrity01:1,
      structuralFailureThreshold01:.18,keelFailureThreshold01:.12,permanentHoleThresholdM2:.004,
      fire:{basis:'GAS_FREE_EMPTY_HULK_OUTFITTING_ONLY',defaultCombustibleKg:2400,machineryCombustibleKg:5200,burnRateKgS:.42,heatDamagePerSecond:.000035,spreadThreshold01:.72,spreadDelayS:75,floodSuppressionStart01:.16}
    },
    flooding:{
      basis:'COARSE_WATERTIGHT_ZONES__NOT_SHIPYARD_SUBDIVISION',seawaterDensityKgM3:1025,gravityMps2:9.80665,dischargeCoefficient:.62,maxSubstepS:.05,
      lightshipDisplacementKg:2.42e7,baselineTransverseGMM:2.45,longitudinalGMM:168,waterplaneAreaM2:5210,freeSurfaceBreadthFactor:.40,responseS:{draft:18,heel:10,trim:18},
      compartments:[
        {id:'FOREPEAK',label:'Forepeak / chain locker',x0:88,x1:105,capacityM3:950,permeability:.74},
        {id:'HOLD_1',label:'Cargo hold No.1',x0:62,x1:88,capacityM3:4200,permeability:.95},
        {id:'HOLD_2',label:'Cargo hold No.2',x0:35,x1:62,capacityM3:5050,permeability:.95},
        {id:'HOLD_3',label:'Cargo hold No.3',x0:8,x1:35,capacityM3:5250,permeability:.95},
        {id:'HOLD_4',label:'Cargo hold No.4',x0:-19,x1:8,capacityM3:5250,permeability:.95},
        {id:'HOLD_5',label:'Cargo hold No.5',x0:-47,x1:-19,capacityM3:5000,permeability:.95},
        {id:'HOLD_6',label:'Cargo hold No.6',x0:-72,x1:-47,capacityM3:4100,permeability:.95},
        {id:'MACHINERY',label:'Secured machinery space',x0:-94,x1:-72,capacityM3:2850,permeability:.68},
        {id:'AFTPEAK',label:'Aft peak / steering flat',x0:-105,x1:-94,capacityM3:720,permeability:.72}
      ],
      survival:{dangerousHeelDeg:14,sinkingDraftIncreaseM:5.25,sunkDraftIncreaseM:9.5,sinkingFloodFraction:.76}
    },
    renderer:{builderId:'EMPTY_CONTAINER_HULK_THREE_V48_WIP13A',rootName:'EMPTY_CONTAINER_TEST_HULK_V1',contract:'PRESENTATION_ONLY_SHARED_PHYSICS_STATIONS',physicsFeedback:false}
  });
  const SURFACE_TARGET_PROFILE_REGISTRY_V48_WIP13A=Object.freeze({[EMPTY_CONTAINER_TEST_HULK_V1.id]:EMPTY_CONTAINER_TEST_HULK_V1});
  const SURFACE_TARGET_ENTITY_REGISTRY_V48_WIP13A=new Map();
  const SURFACE_TARGET_HULL_TRIANGLE_CACHE_V48_WIP13A=new WeakMap();
  let nextSurfaceTargetEntitySerialV48Wip13A=1;



function wip121CorrelateTerminalEffectTracks(originTrackId,event){
    const rows=wip121TerminalEffectCorrelationCandidates(originTrackId,event),applied=[];
    for(const row of rows){
      const linked=wip121RecordFriendlyInterceptEvent(row.trackId,{key:`${event.key}:CORRELATED:${row.trackId}`,reportStep:event.step,effectStep:event.effectStep,weapon:event.weapon,evidence:'DIRECT_BREAKUP',result:event.result,deathReason:event.deathReason,
        source:'TERMINAL_EFFECT_TRACK_CORRELATION',terminalReport:event.terminalReport,correlatedFromTrackId:Number(originTrackId),correlation:row,skipTerminalCorrelation:true});
      if(linked)applied.push({...row,eventKey:linked.key});
    }
    if(applied.length){event.correlatedTrackIds=[...new Set([...(event.correlatedTrackIds??[]),...applied.map(q=>q.trackId)])];event.correlationRows=[...(event.correlationRows??[]),...applied];}
    return applied;
  }

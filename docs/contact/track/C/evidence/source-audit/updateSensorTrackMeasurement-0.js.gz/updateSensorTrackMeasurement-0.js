  function updateSensorTrackMeasurement(id, meas, meta={}){
    const source=meta.source??meas.source??'SENSOR';
    const trackABefore=TRACK_A_DIAG.enabled?trackAStateA(id==null?null:tracks.get(id)):null;
    if(TRACK_A_DIAG.enabled)trackATraceEventA('RECEIVED',meas,{...trackATraceContextA(trackAKindA(meas,source),source,ACTIVE_SHIP_RUNTIME.entityId,meas),route:'PLAYER_MEASUREMENT',trackId:id,decision:'PENDING'});
    const truthRef=normalizeTrackTruthRefV27(meta.truthRef);
    if(id==null&&truthRef)id=trackIdForTruthV27(truthRef.domain,truthRef.objectId,true);
    // Anonymous sensor plots receive a combat-system ID only after association has failed.
    // This allocation carries no reverse truth index and is therefore safe for false plots too.
    if(id==null)id=allocateTrackIdV31();
    let tr=tracks.get(id),created=false;
    if(!tr){
      const ownVxW=mpsToWorldSpeed(Number.isFinite(meas.sensorVxMps)?meas.sensorVxMps:worldSpeedToMps(aircraft._vx??0)),ownVyW=mpsToWorldSpeed(Number.isFinite(meas.sensorVyMps)?meas.sensorVyMps:worldSpeedToMps(aircraft._vy??0));
      const relVxMps=(meas.radialMps??0)*(meas.losUx??0),relVyMps=(meas.radialMps??0)*(meas.losUy??0),relVzMps=(meas.radialMps??0)*(meas.losUz??0);
      tr=getOrMakeTrack(id,meas.x,meas.y,ownVxW+mpsToWorldSpeed(relVxMps),ownVyW+mpsToWorldSpeed(relVyMps),meas.z,relVzMps,truthRef);
      created=true;
      tr.sensorHits=0;tr.confirmed=false;
      // First plot initializes a physically meaningful anisotropic covariance: range/Doppler
      // are relatively well observed, while transverse velocity starts intentionally uncertain.
      tr._kfX=null;tr._kfP=null;
      if(surfaceSensorFamilyWip13B9(source)){
        const surrogate={...meas,elRad:0,radialMps:0,radialVelSigmaMps:180,elSigmaDeg:20,losUz:0};
        trackEkfInit(tr,surrogate);
        tr._kfP[_mIdx(3,3,6)]=SENSOR_MODEL.bridgeMasterE.surfaceVelSigmaInitMps**2;
        tr._kfP[_mIdx(4,4,6)]=SENSOR_MODEL.bridgeMasterE.surfaceVelSigmaInitMps**2;
        tr._kfP[_mIdx(2,2,6)]=SENSOR_MODEL.bridgeMasterE.surfaceZSigmaM**2;
        tr._kfP[_mIdx(5,5,6)]=SENSOR_MODEL.bridgeMasterE.surfaceVzSigmaMps**2;
        trackApplySurfaceDomainConstraint(tr,meas.surfaceReferenceZM??8);
      }else trackEkfInit(tr,meas);
    }

    let trackAAppliedGate=null;
    const isVisual=source==='VISUAL';
    const isBridgeMasterE=source.startsWith('BRIDGEMASTER_E');
    const isSpq9bSurface=source.startsWith('SPQ9B_SURFACE');
    const isSpySurface=source.startsWith('SPY1DV_SURFACE');
    const isSurfaceRadar=isBridgeMasterE||isSpq9bSurface||isSpySurface;
    const isRadar=source.startsWith('SPY1DV') || source.startsWith('SPQ9B');
    if(isSurfaceRadar){
      const gate=isSpySurface?SENSOR_MODEL.spy1dv.surfaceNisGate:(isSpq9bSurface?64:SENSOR_MODEL.bridgeMasterE.nisGate);
      if(TRACK_A_DIAG.enabled)trackAAppliedGate=gate;
      if(!trackEkfUpdateSurfaceRadar2D(tr,meas,{nisGate:gate})){if(TRACK_A_DIAG.enabled)trackATraceEventA('UPDATE',meas,{...trackATraceContextA('SURFACE_RADAR',source,ACTIVE_SHIP_RUNTIME.entityId),route:'PLAYER_MEASUREMENT',trackId:id,decision:'REJECT',reason:'NATIVE_FILTER_REJECT',nis:tr._kfNis,gate,before:trackABefore,after:trackAStateA(tr)});if(created)tracks.delete(id);return null;}
    }else if(isRadar){
      const taskType=meta.taskType??'';
      const nisGate=taskType==='PRECISION_REACQUIRE'?TRACK_FILTER_MODEL.nisGatePrecisionReacquire:(taskType==='TRACK_REACQUIRE'?TRACK_FILTER_MODEL.nisGateReacquire:(taskType.startsWith('SEARCH_')||taskType==='TRACK_CONFIRM'?TRACK_FILTER_MODEL.nisGateSearch:TRACK_FILTER_MODEL.nisGateNormal));
      if(TRACK_A_DIAG.enabled)trackAAppliedGate=nisGate;
      if(!trackEkfUpdateRadar(tr,meas,{nisGate})){if(TRACK_A_DIAG.enabled)trackATraceEventA('UPDATE',meas,{...trackATraceContextA('AIR_RADAR',source,ACTIVE_SHIP_RUNTIME.entityId),route:'PLAYER_MEASUREMENT',trackId:id,decision:'REJECT',reason:'NATIVE_FILTER_REJECT',nis:tr._kfNis,gate:nisGate,before:trackABefore,after:trackAStateA(tr)});if(created)tracks.delete(id);return null;}
    }else if(isVisual){
      meas.altitudeSigmaM=Math.max(30,(meas.rangeSigmaM??100)*0.7);
      trackEkfUpdateCartesianPosition(tr,meas);
    }else{
      // Non-SPY sensor adapters enter the canonical covariance track.
      // A first external plot already initialized P from its covariance: do not count it twice.
      if(!created||source!=='OFFBOARD_C')trackEkfUpdateCartesianPosition(tr,meas);
    }

    if(isRadar&&!isSurfaceRadar)trackNoteAirObservationFC(tr);
    else if(created&&isSurfaceRadar)tr._surface2DOnlyFC=true;
    if(truthRef)bindTrackTruthV27(tr,truthRef);
    tr.truthEnded=false;tr.truthEndReason=null;tr.sensorHits=(tr.sensorHits??0)+1;
    const needHits=isVisual?1:(isSpySurface?SENSOR_MODEL.spy1dv.surfaceConfirmHits:(isSpq9bSurface?2:(isSurfaceRadar?SENSOR_MODEL.bridgeMasterE.confirmHits:SENSOR_MODEL.spy1dv.confirmHits)));
    tr.confirmed=tr.confirmed||tr.sensorHits>=needHits;
    tr.sensorDetected=true;tr.sensorSource=source;tr.sensorAge=0;networkNoteLocalG(ACTIVE_SHIP_RUNTIME,tr,source);
    if(source!=='OFFBOARD_C')tr.identificationEvidence??='LOCAL_SENSOR';
    if(tr.observationReportsC&&source!=='OFFBOARD_C')tr.observationReportsC.localAtS=simStepCounter*SIM_FIXED_DT;
    tr.bearingSigmaDeg=meas.azSigmaDeg??null;tr.elevationSigmaDeg=meas.elSigmaDeg??null;
    tr._lastDetQuality=meas.quality??0.5;tr.ttl=TRACK_HARD_TTL;tr.lastUpdateSeen=true;tr._lastMeasurementStep=simStepCounter;tr.memActive=false;tr._belowHorizon=false;
    if(meta.isASM)tr.isASM=true; // internal association only; classification remains measurement-derived
    if(!(isSurfaceRadar&&trackHasAirObservationFC(tr)))updateTrackClassification(tr,{...meta,domainEvidence:meta.domainEvidence??meas.domainEvidence});
    if(isSurfaceRadar){recordSurfaceSensorContributorWip13B9(tr,source,meas);tr._spyExpectedRevisitS=surfaceTrackExpectedRevisitSWip13B9(tr);}
    trackRefreshDerivedQuality(tr);
    // A3 consumes only the completed observation/classification state. It never reads truth metadata.
    updateTrackOperationalStateA3(tr,{mode:typeof engagementControlMode==='string'?engagementControlMode:'MANUAL',assessment:typeof wip118ControlState==='object'?wip118ControlState?.assessments?.get(id):null});
    if(TRACK_A_DIAG.enabled)trackATraceEventA('UPDATE',meas,{...trackATraceContextA(trackAKindA(meas,source),source,ACTIVE_SHIP_RUNTIME.entityId,meas),route:'PLAYER_MEASUREMENT',trackId:tr.trackId,decision:created?'CREATE':'ACCEPT',nis:isRadar||isSurfaceRadar?tr._kfNis:null,gate:trackAAppliedGate,nativeHitIncrement:1,finalSource:tr.sensorSource,before:trackABefore,after:trackAStateA(tr)});
    return tr;
  }


function heloIffStepE(dt){
  const C=HELO_SENSOR_VALUES_E,ships=[ACTIVE_SHIP_RUNTIME,...physicalShipsB()],now=simStepCounter*SIM_FIXED_DT;
  for(const ship of ships)heloIffExpireE(ship,now);
  if(simStepCounter%Math.max(1,Math.round(C.iffRevisitS/SIM_FIXED_DT))!==0)return;
  for(const ship of ships){
    const replies=heloMeasureIffRepliesE(ship),tracks=observerC(ship).tracks,rx=observerMountC(ship,resolveShipProfile(ship.profileId).geometry.hardpoints.bridgeMasterE),used=new Set();
    for(const reply of replies){let pick=null;
      for(const [id,tr]of tracks){
        if(used.has(id)||(tr.sensorAge??Infinity)>C.iffTrackFreshS)continue;
        const dx=worldToMeters(tr.x-rx.x),dy=worldToMeters(tr.y-rx.y),dz=(tr.z??0)-rx.z,horizontal=Math.hypot(dx,dy),range=Math.hypot(horizontal,dz),cov=trackCovarianceMetrics(tr),sigma=Math.max(1,cov.posSigmaM??100),altSigma=Math.max(1,cov.altSigmaM??sigma),
          dr=Math.abs(range-reply.rangeM),da=Math.abs(angNorm(Math.atan2(dy,dx)-reply.bearing)),de=Math.abs(Math.atan2(dz,Math.max(1,horizontal))-reply.elevationRad),rg=clamp(C.iffGateSigma*Math.hypot(sigma,reply.rangeSigmaM),C.iffRangeGateFloorM,C.iffRangeGateMaxM),
          ag=Math.max(deg(C.iffAngleGateFloorDeg),Math.atan2(C.iffGateSigma*sigma,Math.max(1,range))+C.iffGateSigma*deg(reply.bearingSigmaDeg)),eg=Math.max(deg(C.iffElevationGateFloorDeg),Math.atan2(C.iffGateSigma*altSigma,Math.max(1,range))+C.iffGateSigma*deg(reply.elevationSigmaDeg));
        if(dr>rg||da>ag||de>eg)continue;const score=(dr/rg)**2+(da/ag)**2+(de/eg)**2;if(!pick||score<pick.score)pick={id,tr,score};
      }
      if(!pick)continue;const old=heloFriendlyIffEvidenceE(pick.tr);
      // Keep the operator's independent identity intact so expiry cannot erase an
      // explicit FRIEND/NEUTRAL/HOSTILE annotation. Protection itself is evidence.
      pick.tr.iffF={authenticatedFriendly:true,measuredAtS:reply.measuredAtS,source:'AIR_IFF_E',expiresAtS:now+C.iffHoldS};pick.tr.identity='FRIEND';pick.tr.engagementAuthority='WITHHELD';used.add(pick.id);heloIffReceiverE(ship).associated++;
      if(!old)debugLog(`AIR IFF ${ship.entityId} TRK ${pick.id} 아군 응답 · WITHHELD`);
    }
  }
}
// DIAGNOSTIC_ONLY. Explicit observed-track probes exercise the real release
// gates; normal UI/render code never invokes this port or changes a track.

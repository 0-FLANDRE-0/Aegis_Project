function observerAcceptPlotsC(r,plots,{initiate=true,initiationLimit=OBSERVER_POLICY_C.maxTracks,initiationFamily=null}={}){
  const o=observerC(r),now=simStepCounter*SIM_FIXED_DT,usedTracks=new Set(),usedPlots=new Set(),pairs=[];
  o.stats.plots+=plots.length;plots=plots.slice(0,OBSERVER_POLICY_C.maxPlots);
  const surface=m=>!!m.surfaceReferenceZM;
  // Association knows only covariance, measured geometry, and domain evidence.
  for(let i=0;i<plots.length;i++)for(const [id,tr] of o.tracks){
    if(surface(plots[i])?!trackMayAcceptSurfacePlotCrossDomainWip13B14(tr,plots[i]):!trackMayAcceptAirPlotCrossDomainWip13B14(tr,plots[i])){if(TRACK_A_DIAG.enabled)trackATraceEventA('CANDIDATE',plots[i],{...trackATraceContextA(surface(plots[i])?'SURFACE_RADAR':'AIR_RADAR',plots[i].source,r.entityId),route:'NPC_OBSERVER',trackId:id,decision:'REJECT',reason:'NATIVE_CROSS_DOMAIN_PARTITION'});continue;}
    const nis=surface(plots[i])?trackSurfacePositionAssociationNisWip13B9(tr,plots[i]):trackRadarAssociationNisV31(tr,plots[i]);
    if(TRACK_A_DIAG.enabled)trackATraceEventA('CANDIDATE',plots[i],{...trackATraceContextA(surface(plots[i])?'SURFACE_RADAR':'AIR_RADAR',plots[i].source,r.entityId),route:'NPC_OBSERVER',appliedModel:surface(plots[i])?'SURFACE_POSITION_ONLY':'AIR_POLAR_DOPPLER',appliedDimension:surface(plots[i])?2:4,appliedFields:surface(plots[i])?['rangeM','azRad']:['rangeM','azRad','elRad','radialMps'],gateUnits:'NIS',trackId:id,nis,gate:64,decision:nis<=64?'ELIGIBLE':'REJECT',reason:'NATIVE_NIS'});
    if(nis<=64)pairs.push({i,id,nis,sanity:trackBGeometryB(tr,plots[i],surface(plots[i])?'SURFACE':'AIR'),evidence:trackBEvidenceStableB(tr,plots[i],surface(plots[i])?'SURFACE_POSITION':'AIR',now)});
  }
  pairs.sort((a,b)=>a.nis-b.nis||a.i-b.i||a.id-b.id);
  const trackBSelection=trackBSelectB({plotCount:plots.length,pairs,gate:64,route:'NPC_OBSERVER',observerShip:r.entityId,timeS:now,tick:simStepCounter});
  const apply=(id,meas,created)=>{
    const tr=created?observerNewTrackC(o,meas,surface(meas)):o.tracks.get(id);
    const trackABefore=TRACK_A_DIAG.enabled?trackAStateA(created?null:tr):null;
    const ok=created||(surface(meas)?trackEkfUpdateSurfaceRadar2D(tr,meas,{nisGate:64}):trackEkfUpdateRadar(tr,meas,{nisGate:64}));if(!ok){if(TRACK_A_DIAG.enabled)trackATraceEventA('UPDATE',meas,{...trackATraceContextA(surface(meas)?'SURFACE_RADAR':'AIR_RADAR',meas.source,r.entityId),route:'NPC_OBSERVER',trackId:id,decision:'REJECT',reason:'NATIVE_FILTER_REJECT',before:trackABefore,after:trackAStateA(tr)});o.stats.rejected++;return null;}
    if(!surface(meas))trackNoteAirObservationFC(tr);else if(created)tr._surface2DOnlyFC=true;
    if(created)o.tracks.set(tr.trackId,tr);
    if(now-tr.lastIndependentHitS>=OBSERVER_POLICY_C.confirmationSpacingS){tr.sensorHits++;tr.lastIndependentHitS=now;}
    tr.confirmed=tr.confirmed||tr.sensorHits>=3;tr.sensorAge=0;tr.memActive=false;tr.trackLifecycle=tr.confirmed?'FIRM':'TENTATIVE';tr.sensorSource=meas.source;tr.sensorDetected=true;tr.ttl=OBSERVER_POLICY_C.dropS;
    tr._lastMeasurementStep=simStepCounter;tr.lastMeasurementS=now;tr._lastDetQuality=meas.quality;tr._spyExpectedRevisitS=surface(meas)?o.model.spy1dv.surfaceTrackRevisitS:o.model.spy1dv.trackRevisitAircraftS;
    tr.identificationEvidence??='LOCAL_SENSOR';observerClassifyC(tr,meas);networkNoteLocalG(r,tr,meas.source);if(tr.observationReportsC&&meas.source!=='OFFBOARD_C')tr.observationReportsC.localAtS=now;trackRefreshDerivedQuality(tr);if(surface(meas))fuseSurfaceTrackExtentWip13B8(tr,meas);
    tr.contributorsC??={};tr.contributorsC[meas.source]={measuredAtS:now,quality:meas.quality};
    if(TRACK_A_DIAG.enabled)trackATraceEventA('UPDATE',meas,{...trackATraceContextA(surface(meas)?'SURFACE_RADAR':'AIR_RADAR',meas.source,r.entityId),route:'NPC_OBSERVER',trackId:tr.trackId,decision:created?'CREATE':'ACCEPT',nis:tr._kfNis,finalSource:tr.sensorSource,before:trackABefore,after:trackAStateA(tr)});
    if(created)o.stats.initiated++;else o.stats.associated++;return tr;
  };
  // TRACK-B association-only: SHADOW preserves the original sorted-edge execution,
  // including failed native corrections. ACTIVE tries selected edges, then still
  // admissible original alternatives; each pair is corrected at most once.
  const trackBAttempts=trackBSelection.active?[...trackBSelection.pairs,...pairs]:pairs,trackBTried=trackBSelection.active?new Map():null;
  for(const q of trackBAttempts){
    if(usedTracks.has(q.id)||usedPlots.has(q.i))continue;
    if(trackBSelection.active){
      if(trackBSelection.heldPlots.has(q.i)||trackBSelection.heldTracks.has(q.id)||q.sanity?.ok===false)continue;
      let tried=trackBTried.get(q.i);if(!tried){tried=new Set();trackBTried.set(q.i,tried);}if(tried.has(q.id))continue;tried.add(q.id);
    }
    if(apply(q.id,plots[q.i],false)){usedTracks.add(q.id);usedPlots.add(q.i);}
  }
  for(let i=0;i<plots.length;i++)if(!usedPlots.has(i)){
    if(trackBSelection.active&&trackBSelection.heldPlots.has(i)){o.stats.rejected++;trackBTraceB({route:'NPC_OBSERVER',observerShip:r.entityId,tick:simStepCounter,timeS:now,plotIndex:i,decision:'HOLD',reason:'ASSOCIATION_HOLD_NO_INITIATION'});continue;}
    const familyCount=initiationFamily?[...o.tracks.values()].filter(q=>Object.keys(q.contributorsC??{}).some(k=>k.startsWith(initiationFamily))).length:o.tracks.size;
    if(initiate&&o.tracks.size<OBSERVER_POLICY_C.maxTracks&&familyCount<initiationLimit)apply(null,plots[i],true);else o.stats.rejected++;}
}

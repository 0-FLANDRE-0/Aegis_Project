function stepFriendlyIffF(dt){
  if(simStepCounter%30!==0)return;
  for(const r of electronicShipsF()){
    const o=observerC(r),rx=r.navigation.positionWorld,used=new Set();
    for(const reply of friendlyIffPlotsF(r)){
      let pick=null,best=Infinity;
      for(const [id,tr]of o.tracks){if(tr.domain!=='SURFACE'||used.has(id)||tr.sensorAge>2)continue;const dx=worldToMeters(tr.x-rx.x),dy=worldToMeters(tr.y-rx.y),range=Math.hypot(dx,dy),sigma=trackCovarianceMetrics(tr).posSigmaM??100,dr=Math.abs(range-reply.rangeM),da=Math.abs(angNorm(Math.atan2(dy,dx)-reply.bearing)),rg=Math.max(120,3*Math.hypot(sigma,reply.rangeSigmaM)),ag=deg(Math.max(1,rad2deg(Math.atan2(3*sigma,Math.max(100,range)))));if(dr>rg||da>ag)continue;const score=dr/rg+da/ag;if(score<best){best=score;pick={id,tr};}}
      if(pick){pick.tr.iffF={authenticatedFriendly:true,measuredAtS:reply.measuredAtS};pick.tr._operatorIdentity='FRIEND';pick.tr.identity='FRIEND';pick.tr.engagementAuthority='WITHHELD';used.add(pick.id);}
    }
  }
}

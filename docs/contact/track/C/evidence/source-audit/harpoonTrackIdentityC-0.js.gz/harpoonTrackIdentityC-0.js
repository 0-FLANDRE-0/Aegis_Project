function harpoonTrackIdentityC(tr,owner=ACTIVE_SHIP_RUNTIME){
  if(!tr)return null;
  const records=owner?.weapons?.harpoon?.launches;if(!records?.length)return null;
  const now=simStepCounter,prior=tr._harpoonOwnC,measurementStep=Number(tr._lastMeasurementStep),age=prior?(now-prior.lastStep)*SIM_FIXED_DT:Infinity;
  if(prior&&prior.lastStep===measurementStep){
    if(age<=HARPOON_CORRELATION_G.visibleCoastS)return {identity:prior.confirmed?'FRIEND':'UNKNOWN',reason:prior.confirmed?'OWN_LAUNCH_RADAR_CORRELATION':'POSSIBLE_OWN_LAUNCH'};
    if(prior.confirmed&&age<=HARPOON_CORRELATION_G.reacquireS)return {identity:'UNKNOWN',reason:'OWN_LAUNCH_COAST_UNCERTAIN'};
    tr._harpoonOwnC=null;return null;
  }
  const ranked=[];
  for(const record of records){
    const history=record.lastRadarSampleG,continuation=prior?.launchId===record.id&&prior.hits?prior:history?.confirmed?history:null,
      match=harpoonMatchLaunchC(record,tr,now,continuation);
    if(match)ranked.push({record,match});
  }
  ranked.sort((a,b)=>a.match.score-b.match.score||a.record.id-b.record.id);
  const best=ranked[0],competingFile=best&&[...observerC(owner).tracks.values()].some(q=>q!==tr&&q._harpoonOwnC?.launchId===best.record.id&&q._harpoonOwnC.confirmed&&(now-q._harpoonOwnC.lastStep)*SIM_FIXED_DT<=2),
    ambiguous=ranked.length>1&&ranked[1].match.score-best.match.score<.25||competingFile;
  if(!best){
    const sigma=harpoonObservedSigmaG(tr),X=tr._kfX,speed=X?Math.hypot(X[3],X[4]):0,
      clearlyInbound=prior&&X&&sigma.vel<45&&speed>120&&(X[3]*prior.vx+X[4]*prior.vy)<-.4*speed*Math.hypot(prior.vx,prior.vy);
    if(prior?.confirmed&&age<=HARPOON_CORRELATION_G.reacquireS&&!clearlyInbound)return {identity:'UNKNOWN',reason:'OWN_LAUNCH_CORRELATION_UNCERTAIN'};
    tr._harpoonOwnC=null;return null;
  }
  if(ambiguous){tr._harpoonOwnC={lastStep:measurementStep,confirmed:false,launchId:null,evidence:'AMBIGUOUS_LAUNCH_CORRELATION'};return {identity:'UNKNOWN',reason:'POSSIBLE_OWN_LAUNCH'};}
  const {record,match}=best,confirmed=match.continuedConfirmed||match.hits>=3&&(match.lastStep-match.firstStep)*SIM_FIXED_DT>=.15;
  tr._harpoonOwnC={...match,launchId:record.id,tubeId:record.tubeId,confirmed,evidence:'LAUNCH_CORRELATED_ANONYMOUS_RADAR'};
  if(confirmed){record.claimedTrackId=tr.trackId;record.lastRadarSampleG={...tr._harpoonOwnC};}
  return {identity:confirmed?'FRIEND':'UNKNOWN',reason:confirmed?'OWN_LAUNCH_RADAR_CORRELATION':'POSSIBLE_OWN_LAUNCH'};
}

// LIVE_CANONICAL. Deterministic, owner-local utility decisions over observations.
// Weights/timers are SIM-TUNE. Native ROE, FCS, reserves and release remain final.
const TACTICAL_POLICY_H1=Object.freeze({schema:'AEGIS_UTILITY_TACTICAL_H1_1',minHoldS:2,switchMargin:.08,emergencyS:12,freshS:2,maxTracks:96,maxLog:64});

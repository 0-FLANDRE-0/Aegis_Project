  function updateRadar(dt){
    if(emconActive&&radar.pdTracking){radar.pdTracking=false;radar.mode='TWS';}
    if(shipEquipmentOfflineV1())return;
    setRadarHalfAngle();
    // EMCON suppresses SPY transmissions, but existing track files must still coast/age.
    // The scheduler itself will stop generating/executing radar dwells while silent.
    const ax = aircraft.x(), ay = aircraft.y();
    const ownVx = aircraft._vx, ownVy = aircraft._vy;

    for(const [id,tr] of tracks){
      tr.ttl-=dt;
      tr.sensorAge=(tr.sensorAge??0)+dt;
      if(Number.isFinite(tr._spySurfaceFreshS))tr._spySurfaceFreshS+=dt;
      if(tr.ttl<=0){tracks.delete(id);continue;}

      trackEkfInit(tr);
      const inSector=isInRadarSector(tr.x,tr.y,tr.z);
      const expected=tr._spyExpectedRevisitS??(trackKinematicThreatCue(tr).missileLike?SENSOR_MODEL.spy1dv.trackRevisitAsmS:SENSOR_MODEL.spy1dv.trackRevisitAircraftS);
      const dwellFailed=!!tr._spyDwellFailed;
      const overdue=(tr.sensorAge??0)>Math.max(0.12,expected*1.65);
      const belowHorizon=!!tr._belowHorizon;
      const misses=tr._spyConsecutiveDwellMisses??0;
      const reacqAt=SENSOR_MODEL.spy1dv.reacquireAfterMisses??2;
      const hardAt=SENSOR_MODEL.spy1dv.hardMemAfterMisses??5;

      if(!tr.lastUpdateSeen){
        if(!inSector||belowHorizon){
          tr.memActive=true;tr.memLostOutOfSector=true;tr._memReason=belowHorizon?'HORIZON':'SECTOR';tr.memTime=(tr.memTime??0)+dt;tr.trackLifecycle='MEMORY';
        }else if(dwellFailed){
          if(misses>=hardAt){tr.memActive=true;tr._memReason='MISS';tr.memTime=(tr.memTime??0)+dt;tr.trackLifecycle='MEMORY';}
          else if(misses>=reacqAt){tr.memActive=false;tr.reacquiring=true;tr._memReason='REACQUIRE';tr.trackLifecycle='REACQUIRE';}
          else tr.trackLifecycle='COAST';
        }else if(overdue){
          tr.trackLifecycle='COAST';
          if((tr.sensorAge??0)>Math.max(0.8,expected*5.0)){tr.memActive=true;tr._memReason='STALE';tr.memTime=(tr.memTime??0)+dt;tr.trackLifecycle='MEMORY';}
        }else{
          tr.trackLifecycle=tr.confirmed?'FIRM':'TENTATIVE';
        }
      }else{
        tr.age=0;tr._missFrames=0;tr.memTime=0;
        if(!tr.reacquiring){tr._spyConsecutiveDwellMisses=0;tr._spyLastMissReason=null;tr.memActive=false;tr.memLostOutOfSector=false;tr._memReason=null;}
        tr.trackLifecycle=tr.reacquiring?'REACQUIRE':(tr.confirmed?'FIRM':'TENTATIVE');
      }

      // Mean-state prediction stays deterministic CV. Unknown maneuvering grows covariance Q;
      // it never pushes the estimated target around with random fake acceleration.
      trackEkfPredict(tr,dt,{memory:tr.memActive,reacquire:tr.reacquiring});
      wip11cUpdateObservedSeaImpactTrack(tr,dt);
      tr.age=(tr.age??0)+dt;
      tr._spyDwellFailed=false;
      trackRefreshDerivedQuality(tr);

      const u=trackCovarianceMetrics(tr);
      if((u.posSigmaM>TRACK_FILTER_MODEL.dropPosSigmaM&&tr.sensorAge>4.0)||!Number.isFinite(u.posSigmaM)){
        tracks.delete(id);continue;
      }
      tr.lastUpdateSeen=false;
    }

    // ===== SPY precision-track state =====
    // Manual TRACK is now a high-priority scheduled dwell, not an aircraft-radar tunnel mode.
    // Search, other track files and missile-support tasks continue to compete for beam time.
    if(radar.mode === 'PD' && radar.pdTracking && selectedLockId != null){
      const tr=tracks.get(selectedLockId);
      if(!tr || !trackIsDisplayable(tr)){
        selectedLockId=null;radar.pdTracking=false;radar.trkQuality=1;radar.trkBreakTimer=0;
        updateModeButtonLabel();notify('SPY PREC TRK 종료: 트랙 소실');
      } else {
        const desired=Math.atan2(tr.y-ay,tr.x-ax);
        radar.angle=angNorm(radar.angle+angNorm(desired-radar.angle)*clamp(radar.slaveGain*dt,0,1));
        radar.trkQuality=clamp(tr.trackQuality??0,0,1);
        const pu=trackCovarianceMetrics(tr);
        const precisionHardLost=((tr.sensorAge??0)>3.2 && pu.posSigmaM>1800) || (radar.trkQuality<0.045 && (tr.sensorAge??0)>2.0);
        if(precisionHardLost){
          radar.trkBreakTimer+=dt;
          if(radar.trkBreakTimer>1.20){
            selectedLockId=null;radar.pdTracking=false;radar.trkQuality=1;radar.trkBreakTimer=0;
            updateModeButtonLabel();notify('AN/SPY-1D(V) PREC TRK 손실 — 재획득 실패');
          }
        } else radar.trkBreakTimer=Math.max(0,radar.trkBreakTimer-dt*1.5);

        // Target-side RWR reaction remains a target simulation concern, not a radar truth shortcut.
        // It is only applied to aircraft associated with an already-authorized precision track.
        if(selectedLockId!=null && trackTruthDomainV27(selectedLockId)==='AIR'){
          const t=truthObjectForTrackV27(selectedLockId,true);
          if(t){
            t.threatened=true;t.threatKind='RADAR';t.threatX=ax;t.threatY=ay;
            const closure=Math.max(0,spyTrackClosureMps(tr));
            t.threatLevel=clamp(Math.max(t.threatLevel||0,0.52+clamp(closure/900,0,0.35)),0,1);
            if(!Number.isFinite(t.evadeTimer)||t.evadeTimer<=0){
              t.evadeTimer=rand(2.2,4.0);t.jinkTimer=rand(0.25,0.60);
              if(t.beamSide!==1&&t.beamSide!==-1)t.beamSide=(simRandom()<0.5?-1:1);
              t.lastChaffX=t.x;t.lastChaffY=t.y;t.chaffCooldown=rand(0.15,0.35);
            }
          }
        }
      }
    }

    // Reset LOS flags immediately before the next scheduler pass. A dedicated failed dwell will
    // re-set the flag; during EMCON no new LOS claim is made and track files simply coast/stale.
    if(!emconActive){
      for(const [,tr] of tracks) tr._belowHorizon=false;
    }

    // The scheduler is now the ONLY AN/SPY-1D(V) radar measurement producer.
    // Search cells are independent of truth; focused tasks point at TRACK estimates.
    updateSpyScheduler(dt);
    radar.sweepOffset=angNorm(radar.sweepOffset+deg(35)*dt); // compatibility/HUD reference only
  }


function heloIffExpireE(ship,now){
  const observer=ship.combatSystem.observerC;if(!observer?.heloIffE)return;
  for(const [id,tr]of observer.tracks){if(tr.iffF?.source!=='AIR_IFF_E'||tr.iffF.expiresAtS>now)continue;
    delete tr.iffF;if(tr.identity==='FRIEND')tr.identity=tr._operatorIdentity??'UNKNOWN';tr.engagementAuthority='WITHHELD';
    const state=ship.combatSystem.observerC?.heloIffE;if(state)state.expired++;
    debugLog(`AIR IFF ${ship.entityId} TRK ${id} 응답 만료 · ${tr.identity}`);
  }
}

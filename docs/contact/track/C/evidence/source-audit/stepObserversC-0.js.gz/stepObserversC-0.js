function stepObserversC(dt){
  const own=observerC(ACTIVE_SHIP_RUNTIME);drainOffboardC(ACTIVE_SHIP_RUNTIME);own.tickCount++;own.lastTick=simStepCounter;
  for(const r of physicalShipsB()){
    if(sovNoEquipmentA(r))continue;const o=observerC(r);if(o.lastTick===simStepCounter)throw Error('OBSERVER_DOUBLE_TICK');o.lastTick=simStepCounter;o.tickCount++;
    for(const [id,tr]of o.tracks){tr.sensorAge+=dt;tr.ttl-=dt;tr.memActive=tr.sensorAge>OBSERVER_POLICY_C.coastS;tr.trackLifecycle=tr.memActive?'MEMORY':tr.sensorAge>.65?'COAST':tr.confirmed?'FIRM':'TENTATIVE';trackEkfPredict(tr,dt,{memory:tr.memActive});if(tr.ttl<=0||trackCovarianceMetrics(tr).posSigmaM>TRACK_FILTER_MODEL.dropPosSigmaM)o.tracks.delete(id);}
    o.accumulator+=dt;while(o.accumulator+1e-9>=o.model.spy1dv.schedulerCycleS){o.accumulator-=o.model.spy1dv.schedulerCycleS;observerSpyCycleC(r);}
    observerAuxStepC(r,dt,'SPQ');observerAuxStepC(r,dt,'NAV');drainOffboardC(r);
  }
}


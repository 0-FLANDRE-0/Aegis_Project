function trackHasAirObservationFC(tr){
 return Number.isFinite(tr?._radar3dAirStepFC)&&(simStepCounter-tr._radar3dAirStepFC)*SIM_FIXED_DT<=TRACK_HARD_TTL;
}

  function c55UpdateFile(rec,meas,m,mode,dt){
    const s=rec.st,cfg=CIWS_LOCAL_TRACK_MODEL[m.type],now=CIWS_C55.clockS;
    if(s.localAgeS>cfg.coastS){rec.samples=[];rec.confirmed=false;rec.approachS=0;s.valid=false;s.localHits=0;rec.firstSeenS=now;}
    const elapsed=Math.max(.02,Math.min(.4,s.localAgeS<900?s.localAgeS:cfg.searchDwellS));
    const variances=meas.positionVarianceM2??[36,100,100];
    if(!s.valid||!s._c55P){s.rxM=meas.rxM;s.ryM=meas.ryM;s.rzM=meas.rzM;s.rvxMps=s.rvyMps=s.rvzMps=0;s._c55P=variances.map(v=>[v,0,250000]);s.valid=true;}
    else for(let axis=0;axis<3;axis++){
      const pk=['rxM','ryM','rzM'][axis],vk=['rvxMps','rvyMps','rvzMps'][axis],P=s._c55P[axis],R=Math.max(.5,variances[axis]),innovation=meas[pk]-s[pk],den=P[0]+R,k0=P[0]/den,k1=P[1]/den;
      s[pk]+=k0*innovation;s[vk]+=k1*innovation;const oldCross=P[1];P[0]=Math.max(.01,(1-k0)*P[0]);P[1]=(1-k0)*oldCross;P[2]=Math.max(.01,P[2]-k1*oldCross);
    }
    ciwsCapVectorB3(s,['rvxMps','rvyMps','rvzMps'],2200);s.localHits++;ciwsUpdateManeuverEstimateB3(s,cfg,elapsed);
    s.velocitySigmaMps=Math.sqrt(Math.max(...s._c55P.map(p=>p[2])));
    s.ageS=s.localAgeS=0;s.lastLosQ=meas.losQ;s.lastRangeQ=meas.rangeQ;s.lastSource='LOCAL_RF';
    s.damageSigmaFactor=meas.damageSigmaFactor;s.damagePdFactor=meas.damagePdFactor;s.effectiveRangeKm=meas.effectiveRangeKm;
    s.quality=clamp(s.quality+.16+.24*meas.quality,0,1);
    rec.confirmed=s.localHits>=CIWS_C55_POLICY.confirmHits&&s.velocitySigmaMps<90&&now-rec.firstSeenS>=CIWS_C55_POLICY.confirmSpanS;
  }

  function spq9bAcceptAnonymousPlotsV34(observations){
    const usedTracks=new Set();let accepted=0;let trackBSequenceIndex=-1;
    for(const obs of observations){
      const trackBPlotIndex=TRACK_B_DIAG.enabled?++trackBSequenceIndex:null;
      const plot=obs.plot;SPQ9B_ASSOC_STATS_V34.plots++;
      const match=spq9bBestTrackForPlotV34(plot,usedTracks,trackBPlotIndex),existing=match?tracks.get(match.trackId):null;
      // A fresh SPY estimate already contains this echo at much better 3-D precision. Consume the
      // association so the SPQ return cannot start a duplicate track, but preserve SPY as source.
      if(existing&&isAegisAvailable(existing.x,existing.y)&&(existing.sensorSource??'').startsWith('SPY1DV')&&(existing.sensorAge??99)<0.65){
        if(TRACK_A_DIAG.enabled)trackATraceEventA('ASSIGNMENT',plot,{...trackATraceContextA('AIR_RADAR','SPQ9B_AIR',ACTIVE_SHIP_RUNTIME.entityId),route:'SPQ_SPY_PREFERRED',trackId:existing.trackId,decision:'ASSOCIATE_WITHOUT_HIT',independentHit:false,nis:match.nis,finalSource:existing.sensorSource});
        existing._spq9bFreshS=0;existing._spq9bLastPd=obs.pd;existing._spq9bPanel=obs.panel;updateTrackClassification(existing,{domainEvidence:plot.domainEvidence});usedTracks.add(existing.trackId);SPQ9B_ASSOC_STATS_V34.associated++;SPQ9B_ASSOC_STATS_V34.spyPreferred++;SPQ9B_ASSOC_STATS_V34.lastNis=match.nis;SPQ9B_ASSOC_STATS_V34.lastTrackId=existing.trackId;accepted++;continue;
      }
      const tr=updateSensorTrackMeasurement(match?.trackId??null,plot,{source:'SPQ9B_AIR',domainEvidence:plot.domainEvidence,revisitS:SPQ9B_NOMINAL_REVISIT_S,taskType:'SEARCH_HORIZON'});
      if(!tr){SPQ9B_ASSOC_STATS_V34.rejected++;continue;}
      if(match?.cross){WIP13B14_CROSS_DOMAIN_ASSOC_STATS.airPlotToSurfaceTrack++;WIP13B14_CROSS_DOMAIN_ASSOC_STATS.lastTrackId=tr.trackId;WIP13B14_CROSS_DOMAIN_ASSOC_STATS.lastRoute='AIR';WIP13B14_CROSS_DOMAIN_ASSOC_STATS.lastNis=match.nis;}
      tr._spq9bFreshS=0;tr._spq9bLastPd=obs.pd;tr._spq9bPanel=obs.panel;tr._spyExpectedRevisitS=SPQ9B_NOMINAL_REVISIT_S;tr._spyDwellFailed=false;tr._belowHorizon=false;trackRefreshDerivedQuality(tr);
      usedTracks.add(tr.trackId);SPQ9B_ASSOC_STATS_V34.lastNis=match?.nis??null;SPQ9B_ASSOC_STATS_V34.lastTrackId=tr.trackId;if(match)SPQ9B_ASSOC_STATS_V34.associated++;else SPQ9B_ASSOC_STATS_V34.newTracks++;accepted++;
    }
    return accepted;
  }

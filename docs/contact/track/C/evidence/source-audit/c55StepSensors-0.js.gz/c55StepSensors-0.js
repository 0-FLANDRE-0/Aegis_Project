function c55StepSensors(dt){
    CIWS_C55.clockS+=dt;
    const disabled=emconActive?'EMCON':shipEquipmentOfflineV1()?'SHIP_OFFLINE':getShipDamageEffects().ciwsPowerFac<=.15?'NO_POWER':null;
    if(disabled!==CIWS_C55.disabled){for(const m of ciws){const b=c55Bank(m);b.files.clear();m._localTrack=null;m.trackingTarget=null;m.trackingTrackId=null;m.state='IDLE';m.firing=false;m.tracking=false;m.stateTimer=0;m._shotAccumulator=0;m.turretRate=0;m.turretElRate=0;}CIWS_C55.disabled=disabled;}
    for(const m of ciws){m._c55Managed=true;const b=c55Bank(m);b.winner=null;
      const off=disabled||(!ciwsB3Performance(m).operational?'MOUNT_DAMAGED':ciwsMountStateM(m).zM<=0?'SUBMERGED':null);
      if(off){b.files.clear();b.cues=[];b.status=off;b.reason=off;m._localTrack=null;m.trackingTarget=null;m.trackingTrackId=null;m.cuedTarget=null;m.firing=false;m.tracking=false;m.state='IDLE';continue;}
      const cms=c55CmsRows(m);b.cues=cms.filter(q=>q.cueEligible).sort((a,b)=>a.kin.ttiS-b.kin.ttiS);
      for(const [id,r]of b.files){const s=r.st;ciwsPredictTrackStepB3(s,dt,CIWS_LOCAL_TRACK_MODEL[m.type]);if(s._c55P){const q=s.maneuvering?400:36;for(const P of s._c55P){P[0]+=2*dt*P[1]+dt*dt*P[2]+q*dt*dt*dt/3;P[1]+=dt*P[2]+q*dt*dt/2;P[2]+=q*dt;}}s.ageS+=dt;s.localAgeS+=dt;s.cueAgeS+=dt;s.quality=Math.max(0,s.quality-.07*dt);
        if(s.localAgeS>CIWS_C55_POLICY.expireS){r.proxy.alive=false;b.files.delete(id);CIWS_C55.stats.expired++;}
      }
      c55SensorSweep(m,b,dt);
      for(const r of b.files.values()){
        const s=r.st;c55AssociateCms(r,cms);const kin=ciwsRelativeKinematicsFromState(s.rxM,s.ryM,s.rzM,s.rvxMps,s.rvyMps,s.rvzMps);Object.assign(s,kin);
        s.azRad=Math.atan2(s.ryM,s.rxM);s.elRad=Math.atan2(s.rzM,Math.hypot(s.rxM,s.ryM));
        if(s.localAgeS>CIWS_LOCAL_TRACK_MODEL[m.type].coastS){s.valid=false;r.confirmed=false;}
        const approaching=s.valid&&r.confirmed&&s.localAgeS<CIWS_LOCAL_TRACK_MODEL[m.type].coastS&&kin.closingMps>80&&kin.cpaM<320;
        r.approachS=approaching?r.approachS+dt:0;r.audit=c55ContactAudit(m,r);
      }
      const winners=[...b.files.values()].filter(r=>r.audit?.accepted).sort((a,b)=>a.audit.row.score-b.audit.row.score||a.id-b.id);b.winner=winners[0]?.id??null;
      b.status=b.winner!=null?'LOCAL_DEFENCE':b.cues.length?'CUE_SEARCH':'SEARCH';
      const newest=[...b.files.values()].sort((a,b)=>a.st.rangeM-b.st.rangeM)[0];b.reason=b.winner!=null?b.files.get(b.winner).audit.reason:newest?.audit?.reason??(b.cues.length?'CUE_ONLY_NO_LOCAL_LOCK':'NO_LOCAL_CONTACT');
      if(b.cues.length&&!b.files.size)CIWS_C55.stats.cueOnly++;
    }
  }

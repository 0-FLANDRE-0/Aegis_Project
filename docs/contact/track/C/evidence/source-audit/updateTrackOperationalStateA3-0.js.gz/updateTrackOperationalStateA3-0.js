function updateTrackOperationalStateA3(tr,opts={}){
    if(!tr)return null;
    const prev=`${tr.identity??''}|${tr.threatStatus??''}|${tr.engagementAuthority??''}`;
    const cue=trackKinematicThreatCue(tr),classConf=clamp(Number(tr.classificationConfidence)||0,0,1),hits=Math.max(0,Number(tr.sensorHits)||0);
    const ownLaunch=harpoonTrackIdentityC(tr,ACTIVE_SHIP_RUNTIME);
    const operatorIdentity=ownLaunch?ownLaunch.identity:(heloFriendlyIffEvidenceE(tr)?'FRIEND':normalizeTrackOperatorIdentityA3(tr._operatorIdentity));
    const hostileIntent=tr.confirmed===true&&tr.classification==='ASM'&&classConf>=.58&&hits>=2&&cue.missileLike&&cue.highThreat;
    tr.identity=operatorIdentity!=='UNKNOWN'?operatorIdentity:(!ownLaunch&&hostileIntent?TRACK_A3_IDENTITY.ASSUMED_HOSTILE:TRACK_A3_IDENTITY.UNKNOWN);

    const assessment=opts.assessment??null;
    if(assessment?.state&&Object.prototype.hasOwnProperty.call(TRACK_A3_THREAT,String(assessment.state)))tr.threatStatus=String(assessment.state);
    else if(!tr.confirmed)tr.threatStatus=TRACK_A3_THREAT.UNASSESSED;
    else if(cue.highThreat)tr.threatStatus=TRACK_A3_THREAT.THREAT;
    else tr.threatStatus=TRACK_A3_THREAT.MONITOR;

    const mode=String(opts.mode??'MANUAL').toUpperCase(),explicitFcs=opts.fireControlReady;
    const fcs=explicitFcs==null?trackIsFireControlQuality(tr):!!explicitFcs;
    const protectedIdentity=!!networkProtectionG(ACTIVE_SHIP_RUNTIME,tr)||!!ownLaunch||tr.identity===TRACK_A3_IDENTITY.FRIEND||tr.identity===TRACK_A3_IDENTITY.NEUTRAL;
    const killAssessment=tr.threatStatus===TRACK_A3_THREAT.KILL_ASSESSMENT;
    const terminal=tr.threatStatus===TRACK_A3_THREAT.HARMLESS||tr.threatStatus===TRACK_A3_THREAT.DESTROYED;
    const liveTrack=tr.confirmed===true&&!tr.memActive&&!tr.reacquiring&&fcs;
    if(protectedIdentity||killAssessment||terminal||!liveTrack){tr.engagementAuthority=TRACK_A3_AUTHORITY.WITHHELD;tr._a3AuthorityReason=protectedIdentity?(ownLaunch?.reason??'PROTECTED_IDENTITY'):(killAssessment?'KILL_ASSESSMENT':(terminal?'NON_THREAT':'TRACK_NOT_READY'));}
    else if(mode==='AUTO'){
      const hostile=tr.identity===TRACK_A3_IDENTITY.HOSTILE||tr.identity===TRACK_A3_IDENTITY.ASSUMED_HOSTILE;
      if(hostile&&tr.threatStatus===TRACK_A3_THREAT.THREAT){tr.engagementAuthority=TRACK_A3_AUTHORITY.AUTO_AUTHORIZED;tr._a3AuthorityReason=tr.identity==='HOSTILE'?'OPERATOR_HOSTILE':'HOSTILE_INTENT';}
      else {tr.engagementAuthority=TRACK_A3_AUTHORITY.WITHHELD;tr._a3AuthorityReason=tr.identity==='UNKNOWN'?'IDENTITY_UNKNOWN':'THREAT_NOT_CONFIRMED';}
    }else if(mode==='SEMIAUTO'){tr.engagementAuthority=TRACK_A3_AUTHORITY.OPERATOR_RELEASE;tr._a3AuthorityReason='OPERATOR_RELEASE_REQUIRED';}
    else {tr.engagementAuthority=TRACK_A3_AUTHORITY.MANUAL_ONLY;tr._a3AuthorityReason='MANUAL_TRIGGER_REQUIRED';}
    const next=`${tr.identity}|${tr.threatStatus}|${tr.engagementAuthority}`;
    if(next!==prev){tr._a3StateRevision=(tr._a3StateRevision??0)+1;tr._a3StateChangedStep=typeof simStepCounter==='number'?simStepCounter:0;}
    return tr;
  }

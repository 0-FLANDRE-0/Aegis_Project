function wip121TransferEngagementMemory(oldTrackId,newTrackId){
    const oldId=Number(oldTrackId),newId=Number(newTrackId);if(oldId===newId)return false;networkTransferAliasG(ACTIVE_SHIP_RUNTIME,oldId,newId);const r=wip119AutonomyState?.responses?.get(oldId);if(r&&!wip119AutonomyState.responses.has(newId)){wip119AutonomyState.responses.delete(oldId);r.trackId=newId;wip119AutonomyState.responses.set(newId,r);}
    if(wip119AutonomyState?.pending?.trackId===oldId)wip119AutonomyState.pending.trackId=newId;
    for(const m of missiles)if(!m.dead&&m.assignedTargetId===oldId){m.assignedTargetId=newId;weaponLinkB3Rebind(m,newId);}
    for(const rm of ramMissiles)if(rm.alive&&rm.targetId===oldId)rm.targetId=newId;
    for(const b of ciwsBullets)if(b.engagementTrackId===oldId)b.engagementTrackId=newId;
    for(const mount of ciws){if(mount.trackingTrackId===oldId)mount.trackingTrackId=newId;if(mount.cuedTarget===oldId)mount.cuedTarget=newId;}
    const live=SPG62_ENGAGEMENT_STATE.get(oldId);if(live){SPG62_ENGAGEMENT_STATE.delete(oldId);if(!SPG62_ENGAGEMENT_STATE.has(newId))SPG62_ENGAGEMENT_STATE.set(newId,live);}
    const reservation=SPG62_RESERVATION_STATE.get(oldId);if(reservation){SPG62_RESERVATION_STATE.delete(oldId);reservation.targetId=newId;if(!SPG62_RESERVATION_STATE.has(newId))SPG62_RESERVATION_STATE.set(newId,reservation);}
    for(const rows of SPG62_RESERVATIONS.values())for(const row of rows)if(row.targetId===oldId)row.targetId=newId;
    for(const v of ACTIVE_SHIP_RUNTIME.combatSystem.fireControl.spg62Servo.mounts)if(v.targetTrackId===oldId)v.targetTrackId=newId;
    const oldHandoff=WIP122_SM2_HANDOFF_MEMORY.get(oldId);if(oldHandoff){WIP122_SM2_HANDOFF_MEMORY.delete(oldId);WIP122_SM2_HANDOFF_MEMORY.set(newId,oldHandoff);}for(const p of defenseE.closeIn.values())if(p.command.trackId===oldId)p.command.trackId=newId;for(const m of [...missiles,...ramMissiles])if((m.assignedTargetId??m.targetId)===newId)m.ownerTrackKeyD=ownerTrackKeyD(owner.entityId,newId);for(const mount of ciws)for(const file of c55Bank(mount).files.values())if(file.cmsTrackId===oldId)file.cmsTrackId=newId;if(selectedLockId===oldId)selectedLockId=newId;SPG62_RESERVATION_META.lastPlanStep=-1;return true;
  }

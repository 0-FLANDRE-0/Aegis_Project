REPORT.html을 열면 결과와 스크린샷을 볼 수 있습니다. 게임 HTML은 별도 HTML ZIP에 있습니다. 원격 readback 영수증은 저장소 docs/map/C/remote-readback.json에 별도 기록됩니다(아카이브 자체 해시의 순환 참조 방지).

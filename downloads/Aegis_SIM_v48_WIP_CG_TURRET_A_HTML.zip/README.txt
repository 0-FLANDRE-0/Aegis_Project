압축을 풀고 Aegis_SIM_v48_WIP_CG_TURRET_A.html을 브라우저에서 여세요.

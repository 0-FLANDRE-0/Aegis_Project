INDEX.html을 여세요. PC/폰 비교 캡처와 보고서, 원시시험·로그·diff·도구를 포함합니다. historical/은 B2B 비교 입력입니다. 게임 HTML은 별도 ZIP입니다.

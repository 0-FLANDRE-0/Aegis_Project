REPORT.html을 여세요. 정식 원시 로그는 docs/gun/B2/evidence/trials/입니다. development/pilot 자료는 비교에서 제외한 개발 기록입니다. 제품 HTML은 변경하지 않았고 이 ZIP에 포함하지 않습니다. 원격 검증 영수증은 ZIP 생성 뒤 별도 커밋에 기록합니다.

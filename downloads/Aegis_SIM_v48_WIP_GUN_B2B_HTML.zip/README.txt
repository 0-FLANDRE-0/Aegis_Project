압축 해제한 Aegis_SIM_v48_WIP_GUN_B2.html을 브라우저로 여세요. GUN_B2B 게임용 SIM_TUNED 빌드입니다. 원시 검증과 보고서는 별도 REPORT.zip에 있습니다.

REPORT.html을 브라우저에서 열면 검증 결과와 스크린샷을 볼 수 있습니다. 게임 HTML은 별도 HTML ZIP에 있습니다. 상세 파일은 docs/map/B 아래에 있습니다.

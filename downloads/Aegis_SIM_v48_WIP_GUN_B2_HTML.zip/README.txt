Aegis_SIM_v48_WIP_GUN_B2.html을 압축 해제한 뒤 브라우저로 여세요. 게임용 SIM_TUNED 모델입니다. 전체 검증과 새 ON 차이는 별도 PHASE1_REPORT.zip에 있습니다.

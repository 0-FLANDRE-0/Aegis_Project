REPORT.html을 열면 검증 결과와 스크린샷을 볼 수 있습니다. 게임 HTML은 별도 HTML ZIP에 있습니다. 원격 readback 영수증은 저장소 docs/map/D/remote-readback.json에 별도 기록합니다(아카이브 자체 해시 순환 참조 방지).

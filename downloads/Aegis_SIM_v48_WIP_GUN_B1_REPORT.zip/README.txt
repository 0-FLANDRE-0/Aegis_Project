REPORT.html을 열면 보고서·그래프·스크린샷을 볼 수 있습니다. 게임 HTML은 별도 HTML ZIP입니다. 원격 readback 영수증은 저장소 docs/gun/B1/remote-readback.json에 별도 후속 커밋으로 기록합니다.
